# 种树的人网站共用规则

正式入口为 https://zhongshuderen-research.netlify.app/ 。唯一公开仓库为 `linfei6679-star/zhongshuderen-research` 的 `main`；不得把旧 Sites 远端当作当前发布目标。

- 用户已确认简洁交互 C：**首页仅个人形象、搜索/探索、联系与真实访客小字**。禁止资料更新顺带添加文章摘要、推荐卡、项目进度或数量到首页。
- 搜索和专题是第二级；独立研究正文是第三级。旧文章 URL、正文、来源、日期、反例及未知状态保留；HTML、Markdown、目录及机器索引由统一公开数据生成。
- 必须先读 `docs/CONTENT_PIPELINE.md`。资料增加后自动进入搜索，常规日更只写 `public-research-data.json` 或 `data/visitor-stats.json`，跳过源码构建。
- 原研究工程只读，不执行源工程代码，不训练/回测/派工。不得把源码完成、程序运行、原项目复核、历史假设混成一种成果。
- 更新前重读线上数据与待更新条目；按稳定 ID 去重并做基线哈希校验。保留未涉及内容，旧观点的更正需保留原语境和更正证据。
- 发布前运行 `scripts/validate-content-intake.mjs`；读取 `private/publication-coordination.json`，另一入口持有发布窗口时仅准备增量候选。
- 沿用已有来源登记、日更游标和访问统计。成功读回公开结果前不能推进游标。无实质变化不提交；旧材料补记不冒充今日成果。
- 数据对话不能修改 `lib/home-page.js`、`lib/site-chrome.js`、`public/site-ui.*`、部署规则或源码包。样式/检索工程变更由设计维护入口处理并做适用测试。
- 零新增现金，不扩展权限、提取令牌、创建凭据或升级服务。不能发布内部路径、账号、凭据、雇主或未筛选原文。
- 本地只维护唯一共享输入和必要源码/回执；不复制完整工程、依赖、行情或原始文档。已拒绝的清理不能换工具重试。
- 其他项目的已审成果归属项目/专题和独立正文，并通过 `scripts/prepare-content-release.mjs` 同步到“成果更新”目录；首页只保留小导航。未审材料登记私有接收状态。GitHub 根目录的 `CONTENT_PIPELINE.md` 与解包源码中的 `docs/CONTENT_PIPELINE.md` 是同一规则。
