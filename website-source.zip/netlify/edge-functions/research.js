import {seed,website} from '../../lib/generated-seed.js';
import {createReader} from '../../lib/public-research-reader.js';
const dataUrl=Deno.env.get('RESEARCH_DATA_URL')||website.data_url||'';
const handler=createReader({seed,origin:website.origin,dataUrl});
export default handler;
