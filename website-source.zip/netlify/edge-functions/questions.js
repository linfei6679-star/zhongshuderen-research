import {website} from '../../lib/generated-seed.js';
import {createQuestionsReader} from '../../lib/public-questions.js';

export default createQuestionsReader({origin:website.origin});
