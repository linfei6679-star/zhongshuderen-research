(()=>{
 const node=document.getElementById('stock-table-data'),board=document.querySelector('.stock-board');if(!node||!board)return;
 const records=JSON.parse(node.textContent),fixed=board.dataset.fixedTopic,rows=new Map([...document.querySelectorAll('.stock-row')].map(row=>[row.dataset.code,row]));
 const $=id=>document.getElementById(id),q=$('stock-search'),topic=$('stock-topic'),level=$('stock-level'),sort=$('stock-sort'),date=$('stock-date');
 const compact=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/\s+/g,''),clip=(s,n)=>s.length>n?s.slice(0,n)+'…':s;
 const format=s=>Number.isFinite(Date.parse(s))?new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(s)):'更新时间未提供';
 let shown=new Map();
 const order=(a,b)=>sort.value==='source'?b.sourceMs-a.sourceMs||b.updatedMs-a.updatedMs||a.code.localeCompare(b.code):b.updatedMs-a.updatedMs||b.sourceMs-a.sourceMs||a.code.localeCompare(b.code);
 function reportLink(r){return '/library/'+r.id+'/?'+new URLSearchParams({board:fixed,from:q.value.trim(),level:level.value,sort:sort.value,...(date.value?{date:date.value}:{})});}
 function filter(){
  const query=compact(q.value),selectedTopic=topic?.value||fixed;
  const filtered=records.filter(r=>(selectedTopic==='all'||r.topic===selectedTopic)&&(!query||r.search.includes(query))&&(!date.value||r.updated.slice(0,10)===date.value));
  shown=new Map();for(const r of filtered){if(!shown.has(r.code))shown.set(r.code,[]);shown.get(r.code).push(r);}const groups=[...shown].map(([code,cases])=>({code,cases:cases.sort(order),updatedMs:Math.max(...cases.map(r=>r.updatedMs)),sourceMs:Math.max(...cases.map(r=>r.sourceMs))})).filter(g=>level.value==='all'||level.value==='focus'&&g.cases.some(r=>r.focus)||level.value==='risk'&&g.cases.some(r=>!r.focus)).sort(order);shown=new Map(groups.map(g=>[g.code,g.cases]));
  for(const row of rows.values())row.hidden=true;
  for(const g of groups){const row=rows.get(g.code),r=g.cases[0];row.hidden=false;row.querySelector('[data-row-date]').textContent=format(r.updated);row.querySelector('[data-row-period]').textContent='资料期间：'+clip(r.periods||'见原报告',45);row.querySelector('[data-row-count]').textContent=g.cases.length+' 项研究';row.querySelector('[data-row-subject]').textContent=clip(r.subject,85);row.querySelector('[data-row-reason]').textContent=clip(r.reason,145);row.querySelector('[data-row-more]').textContent=g.cases.length>1?'同一股票的各项业务分别保留，点名称展开。':'';row.querySelector('[data-row-direction]').textContent=[...new Set(g.cases.map(c=>c.direction))].join(' / ');row.querySelector('[data-primary-report]').href=reportLink(r);$('stock-rows').append(row);}
  $('stock-visible').textContent='当前显示 '+groups.length+' 家股票 · '+groups.reduce((n,g)=>n+g.cases.length,0)+' 项研究';$('stock-empty').hidden=groups.length>0;
  const params=new URLSearchParams();if(q.value.trim())params.set('q',q.value.trim());if(topic&&topic.value!=='all')params.set('topic',topic.value);if(level.value!=='focus')params.set('level',level.value);if(sort.value!=='latest')params.set('sort',sort.value);if(date.value)params.set('date',date.value);history.replaceState(null,'',location.pathname+(params.size?'?'+params:'')+location.hash);
 }
 for(const field of [q,topic,level,sort,date].filter(Boolean))field.addEventListener('input',filter);
 board.querySelector('form').addEventListener('submit',e=>{e.preventDefault();filter();});
 board.addEventListener('click',e=>{const trigger=e.target.closest('[data-stock]');if(!trigger)return;const cases=shown.get(trigger.dataset.stock)||records.filter(r=>r.code===trigger.dataset.stock);if(!cases.length)return;const body=$('stock-detail-body');body.replaceChildren();$('stock-detail-title').textContent=cases[0].name+' · '+cases[0].code+'（'+cases.length+'项研究）';for(const r of cases){const template=$('stock-case-'+r.id);if(template){const fragment=template.content.cloneNode(true);fragment.querySelector('.report-link').href=reportLink(r);body.append(fragment);}}$('stock-detail').showModal();$('stock-detail').scrollTop=0;});
 $('stock-detail-close').addEventListener('click',()=>$('stock-detail').close());filter();
})();
