(()=>{
 const site=document.getElementById('site'),dialog=document.getElementById('site-contact');
 let reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 function motion(value){reduced=value;site?.classList.toggle('reduced',value);document.getElementById('motion')?.setAttribute('aria-pressed',String(value));const art=document.getElementById('hero-art');if(art)for(const k of ['--art-x','--art-y','--art-r'])art.style.removeProperty(k);}
 motion(reduced);document.getElementById('motion')?.addEventListener('click',()=>motion(!reduced));
 document.querySelectorAll('[data-contact]').forEach(a=>a.addEventListener('click',e=>{if(dialog?.showModal){e.preventDefault();dialog.showModal();}}));
 document.getElementById('site-contact-close')?.addEventListener('click',()=>dialog.close());
 document.getElementById('site-contact-copy')?.addEventListener('click',async()=>{const state=document.getElementById('site-copy-state');try{await navigator.clipboard.writeText('13359246679');state.textContent='已复制，到微信添加朋友即可。';}catch{state.textContent='请手动复制：13359246679';}});
 const input=document.getElementById('home-query'),suggestions=document.getElementById('suggestions'),items=document.getElementById('suggestion-items');
 if(input&&suggestions&&items){
  const ideas=['AI制药','量化','宏观','成都先导'];
  function suggest(){const typed=input.value.toLowerCase().trim(),options=ideas.filter(q=>!typed||q.toLowerCase().includes(typed));items.replaceChildren(...options.map(q=>{const a=document.createElement('a');a.href='/library/?'+new URLSearchParams({q});a.textContent=q+' ↗';a.style.cssText='display:inline-block;font-size:12px;color:var(--red);padding:5px 0;margin-right:18px';return a;}));suggestions.hidden=!options.length;input.setAttribute('aria-expanded',String(!suggestions.hidden));}
  input.addEventListener('focus',suggest);input.addEventListener('input',suggest);
  document.addEventListener('click',e=>{if(!e.target.closest('.search-area')){suggestions.hidden=true;input.setAttribute('aria-expanded','false');}});
 }
 const art=document.getElementById('hero-art');
 if(art){art.addEventListener('pointermove',e=>{if(reduced||e.pointerType==='touch')return;const r=art.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;art.style.setProperty('--art-x',x*8+'px');art.style.setProperty('--art-y',y*5+'px');art.style.setProperty('--art-r',x*1.4+'deg');});art.addEventListener('pointerleave',()=>{for(const k of ['--art-x','--art-y','--art-r'])art.style.removeProperty(k);});}
 document.getElementById('surprise')?.addEventListener('click',()=>{const topics=['AI制药','量化','宏观','哲学'],draw=Math.floor(Math.random()*topics.length);location.assign('/library/?'+new URLSearchParams({q:topics[draw],draw:String(draw)}));});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&suggestions){suggestions.hidden=true;input?.setAttribute('aria-expanded','false');}if(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!dialog?.open&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||'')){e.preventDefault();const field=input||document.getElementById('result-query')||document.getElementById('stock-search');if(field)field.focus();else location.assign('/library/');}});
 const progress=document.getElementById('reading-progress');if(progress&&document.querySelector('.article-body')){progress.hidden=false;const update=()=>{const denominator=document.documentElement.scrollHeight-innerHeight;document.documentElement.style.setProperty('--read-progress',(denominator>0?Math.min(100,scrollY/denominator*100):100)+'%');};addEventListener('scroll',update,{passive:true});update();}
 if(location.hash==='#contact')dialog?.showModal();else if(['#start-reading','#topics','#search'].includes(location.hash))input?.focus();
})();
