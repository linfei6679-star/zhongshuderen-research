/* Progressive enhancement only: without JS the same named Netlify form posts natively. */
(()=>{
  const form=document.getElementById('master-question-form');
  if(!form)return;
  const submit=document.getElementById('ask-submit');
  const status=document.getElementById('ask-submit-status');
  const question=document.getElementById('ask-question');
  const counter=document.getElementById('ask-question-count');
  const preview=document.getElementById('ask-preview-note');
  const contactType=document.getElementById('ask-contact-type');
  const contact=document.getElementById('ask-reply-contact');
  const localPreview=location.hostname==='localhost'||/^127\./.test(location.hostname)||location.hostname==='[::1]';
  let sending=false;

  function count(){counter.textContent=`${question.value.length.toLocaleString('en-US')} / 2,000`;question.setCustomValidity('');}
  function contactHint(){
    const email=contactType.value==='email';
    contact.placeholder=email?'方便联系你的邮箱':'方便联系你的微信号';
    contact.setAttribute('inputmode',email?'email':'text');
  }
  count();contactHint();
  question.addEventListener('input',count);
  contactType.addEventListener('change',contactHint);
  if(localPreview){preview.hidden=false;submit.firstChild.textContent='预览提交';}

  form.addEventListener('submit',async event=>{
    event.preventDefault();
    if(sending)return;
    if(!form.reportValidity())return;
    if(question.value.trim().length<10){question.setCustomValidity('请至少写下 10 个有效字符，方便我理解你的问题。');question.reportValidity();return;}
    if(localPreview){status.textContent='这是预览，问题尚未发送。填写的内容已保留。';status.focus?.({preventScroll:true});return;}
    sending=true;submit.disabled=true;form.setAttribute('aria-busy','true');
    status.textContent='正在提交，请稍候……';
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),25000);
    try{
      const payload=new URLSearchParams();
      for(const [name,value] of new FormData(form))if(typeof value==='string')payload.append(name,value);
      const response=await fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:payload.toString(),signal:controller.signal,credentials:'same-origin'});
      if(!response.ok)throw new Error('FORM_NOT_ACCEPTED');
      status.textContent='提交完成，正在前往确认页。';
      location.assign(form.action);
    }catch(error){
      status.textContent=error?.name==='AbortError'
        ?'暂时无法确认是否收到你的问题，填写内容已保留。请稍后重试，或加微信 13359246679 核对。'
        :'提交未成功，填写内容已保留。请稍后重试，或加微信 13359246679 交流。';
    }finally{
      clearTimeout(timeout);sending=false;submit.disabled=false;form.removeAttribute('aria-busy');
    }
  });
})();
