/**
 * Local, dependency-free examples for the design library.
 * No real research data, network requests, storage, or global event listeners.
 * mountInteractionDemos(container) returns a cleanup function; remounts clean up first.
 */
export const interactionPatterns = Object.freeze([
  {id:'branch-choice',name:'枝头选题',usage:'专题入口、探索页',motion:'芽点轻亮，内容即时切换',keyboard:'Tab 选择按钮，Enter 或空格切换'},
  {id:'evidence-fold',name:'证据展笺',usage:'研究正文、资料来源',motion:'展开正文，不自动移动页面',keyboard:'Tab 定位标题，Enter 或空格展开'},
  {id:'research-steps',name:'沿线阅读',usage:'研究方法、阅读路线',motion:'当前步骤暖红提示，无进度动画',keyboard:'Tab 选择步骤，Enter 或空格切换'},
  {id:'condition-compare',name:'条件对照',usage:'假设、反证与条件说明',motion:'单个面板原位切换',keyboard:'Tab 选择条件，Enter 或空格切换'},
  {id:'quiet-lift',name:'轻抬一页',usage:'二级目录、相关文章',motion:'悬停或聚焦上移 3px，不旋转',keyboard:'Tab 聚焦，Enter 或空格标记示例'},
  {id:'detail-dialog',name:'留白阅览',usage:'二级表格、研究事项详情',motion:'原生对话框，无飞入动画',keyboard:'Enter 打开，Tab 浏览，Esc 关闭并返回入口'}
].map(item => Object.freeze(item)));

const mounted = new WeakMap();
let sequence = 0;
const branchCopy = [
  ['理解公司','交互示例：从一个问题出发，进入对应的公司研究专题。'],
  ['观察市场','交互示例：用简短入口连接市场变化、资料日期与研究依据。'],
  ['探索方法','交互示例：把方法说明放到第二级，完整论证留给研究正文。']
];
const stepCopy = [
  ['提出问题','交互示例：先说明想理解什么，以及问题的边界。'],
  ['寻找依据','交互示例：展示证据的类型与日期，不把材料数量当作结论。'],
  ['保留反证','交互示例：列出可能推翻判断的条件，以及尚未确认的部分。']
];
const conditionCopy = [
  ['假设成立时','交互示例：展示一个假设需要满足的条件。这里没有真实研究判断。'],
  ['出现反证时','交互示例：呈现反向证据与修改判断的理由，两个方向占据同等位置。']
];

export function mountInteractionDemos(container) {
  if (!container || container.nodeType !== 1 || typeof container.replaceChildren !== 'function') {
    throw new TypeError('mountInteractionDemos 需要一个 HTML 容器元素。');
  }
  mounted.get(container)?.();
  const doc = container.ownerDocument;
  const abort = new doc.defaultView.AbortController();
  const prefix = `ds-demo-${++sequence}`;
  const root = doc.createElement('div');
  root.className = 'ds-demo ds-demo-grid';
  root.setAttribute('aria-label','可操作的交互示例');
  let disposed = false;
  let returnFocus = null;

  function tile(pattern, body) {
    return `<article class="ds-demo-tile demo-tile" data-pattern="${pattern.id}" aria-labelledby="${prefix}-${pattern.id}-title">
      <header class="ds-demo-head"><span class="ds-demo-kicker">交互示例</span><h3 id="${prefix}-${pattern.id}-title">${pattern.name}</h3><p>${pattern.usage}</p></header>
      <div class="ds-demo-stage">${body}</div>
      <footer class="ds-demo-foot"><span>${pattern.motion}</span><small>${pattern.keyboard}</small></footer>
    </article>`;
  }
  function choices(list, type, name) {
    return `<div class="ds-demo-choices" role="group" aria-label="${name}">${list.map((item,i) => `<button type="button" class="ds-demo-choice" data-action="${type}" data-index="${i}" aria-pressed="${i===0}" aria-controls="${prefix}-${type}-panel">${item[0]}</button>`).join('')}</div>`;
  }
  function panel(list, type) {
    return `<div class="ds-demo-panel" id="${prefix}-${type}-panel" role="status" aria-live="polite" aria-atomic="true"><h4>${list[0][0]}</h4><p>${list[0][1]}</p></div>`;
  }
  root.innerHTML = [
    tile(interactionPatterns[0], `<div class="ds-demo-branch-art" aria-hidden="true"><svg viewBox="0 0 300 95"><path d="M28 80Q126 73 271 22M111 68Q118 43 101 22M182 49Q190 66 220 70"/><ellipse cx="102" cy="20" rx="4" ry="8" transform="rotate(-22 102 20)"/><ellipse cx="273" cy="21" rx="4" ry="8" transform="rotate(54 273 21)"/><ellipse cx="222" cy="70" rx="4" ry="8" transform="rotate(-70 222 70)"/></svg></div>${choices(branchCopy,'branch','枝头主题')}${panel(branchCopy,'branch')}`),
    tile(interactionPatterns[1], `<p class="ds-demo-caption">让论据近在手边，让正文保有呼吸。</p><details class="ds-demo-evidence"><summary><span>展开一条依据</span><span class="ds-demo-plus" aria-hidden="true">＋</span></summary><div><p><strong>交互示例 · 资料摘记</strong></p><p>这里放来源名称、材料日期，以及与问题直接相关的一句话。</p><p class="ds-demo-note">正式使用时填写可核对的来源；未核实的内容保留原状态。</p></div></details><details class="ds-demo-evidence"><summary><span>还有哪些未知</span><span class="ds-demo-plus" aria-hidden="true">＋</span></summary><div><p>交互示例：证据缺口、不同解释、后续验证条件均在此保留。</p></div></details>`),
    tile(interactionPatterns[2], `<p class="ds-demo-caption">阅读路线示例，不表示任何项目的实际进度。</p><div class="ds-demo-steps" role="group" aria-label="阅读步骤">${stepCopy.map((item,i) => `<button type="button" class="ds-demo-step" data-action="step" data-index="${i}" aria-current="${i===0?'step':'false'}" aria-controls="${prefix}-step-panel"><span aria-hidden="true">0${i+1}</span>${item[0]}</button>`).join('')}</div>${panel(stepCopy,'step')}`),
    tile(interactionPatterns[3], `<p class="ds-demo-caption">观点和反证，共用一张安静的纸。</p>${choices(conditionCopy,'condition','示例条件对照')}${panel(conditionCopy,'condition')}`),
    tile(interactionPatterns[4], `<button type="button" class="ds-demo-reading-card" data-action="lift" aria-pressed="false" aria-describedby="${prefix}-lift-note"><span class="ds-demo-card-mark" aria-hidden="true">↗</span><span class="ds-demo-kicker">交互示例 · 阅读入口</span><strong>一个问题，<br>一页新的理解。</strong><span class="ds-demo-card-hint">触碰、聚焦，再轻轻打开。</span></button><p class="ds-demo-selection" id="${prefix}-lift-note" role="status" aria-live="polite">试着用鼠标悬停，或用 Tab 聚焦这张卡。</p>`),
    tile(interactionPatterns[5], `<div class="ds-demo-dialog-invite"><span class="ds-demo-sheet-icon" aria-hidden="true"><i></i><i></i><i></i></span><p>把细节放近一点，<br>让当前页面保持简洁。</p><button type="button" class="ds-demo-open" data-action="open-dialog" aria-haspopup="dialog" aria-controls="${prefix}-dialog">打开示例详情 <span aria-hidden="true">↗</span></button></div><dialog class="ds-demo-dialog" id="${prefix}-dialog" aria-labelledby="${prefix}-dialog-title" aria-describedby="${prefix}-dialog-description"><div class="ds-demo-dialog-body"><button type="button" class="ds-demo-close" data-action="close-dialog" aria-label="关闭示例详情" autofocus>×</button><p class="ds-demo-kicker">交互示例 · 详情阅览</p><h4 id="${prefix}-dialog-title">在留白里，<br>把事情看清楚。</h4><p id="${prefix}-dialog-description">这是可复用的交互演示，没有真实研究数据。正式使用时可装入事项说明、材料日期、依据与未知。</p><dl><div><dt>问题</dt><dd>需要理解的具体问题。</dd></div><div><dt>依据</dt><dd>可核对的来源与材料日期。</dd></div><div><dt>边界</dt><dd>反证、尚待验证与不确定性。</dd></div></dl><button type="button" class="ds-demo-open" data-action="close-dialog">返回刚才的位置 <span aria-hidden="true">↗</span></button></div></dialog>`)
  ].join('');
  container.replaceChildren(root);
  const dialog = root.querySelector('.ds-demo-dialog');

  function select(button, type, content) {
    const index = Number(button.dataset.index);
    if (!content[index]) return;
    const localTile = button.closest('[data-pattern]');
    localTile.querySelectorAll(`[data-action="${type}"]`).forEach(item => {
      if (type === 'step') item.setAttribute('aria-current', item === button ? 'step' : 'false');
      else item.setAttribute('aria-pressed', String(item === button));
    });
    const output = localTile.querySelector('.ds-demo-panel');
    output.querySelector('h4').textContent = content[index][0];
    output.querySelector('p').textContent = content[index][1];
  }
  root.addEventListener('click', event => {
    const button = event.target.closest?.('button[data-action]');
    if (!button || !root.contains(button)) return;
    switch (button.dataset.action) {
      case 'branch': select(button,'branch',branchCopy); break;
      case 'step': select(button,'step',stepCopy); break;
      case 'condition': select(button,'condition',conditionCopy); break;
      case 'lift': {
        const active = button.getAttribute('aria-pressed') !== 'true';
        button.setAttribute('aria-pressed',String(active));
        root.querySelector('.ds-demo-selection').textContent = active
          ? '交互示例：已选择这张卡。再次点击可取消。'
          : '试着用鼠标悬停，或用 Tab 聚焦这张卡。';
        break;
      }
      case 'open-dialog':
        if (!dialog.open) { returnFocus = button; dialog.showModal(); }
        break;
      case 'close-dialog': dialog.close(); break;
    }
  }, {signal:abort.signal});
  dialog.addEventListener('close', () => {
    if (!disposed && returnFocus?.isConnected) returnFocus.focus({preventScroll:true});
    returnFocus = null;
  }, {signal:abort.signal});

  const cleanup = () => {
    if (disposed) return;
    disposed = true;
    abort.abort();
    if (dialog.open) dialog.close();
    returnFocus = null;
    root.remove();
    if (mounted.get(container) === cleanup) mounted.delete(container);
  };
  mounted.set(container,cleanup);
  return cleanup;
}
