import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {validatePublicSnapshot} from '../lib/public-research-reader.js';
import {entryPath,renderKnowledge,renderKnowledgeMarkdown} from '../lib/knowledge-library.js';
import {searchDocuments,rankResearch} from '../lib/research-search.js';
import {renderHome} from '../lib/home-page.js';
const origin='https://zhongshuderen-research.netlify.app';
const digest=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function validateContentUpdate(baseline,candidate,review=[]){
 validatePublicSnapshot(baseline);validatePublicSnapshot(candidate);
 const serialized=JSON.stringify(candidate);if(serialized.length>8388608)throw Error('Public data exceeds current reader capacity; review capacity before publishing');
 if(Date.parse(candidate.checked_at)<Date.parse(baseline.checked_at))throw Error('Candidate predates the live baseline');
 const before=new Map(baseline.knowledge.entries.map(e=>[e.id,e])),after=new Map(candidate.knowledge.entries.map(e=>[e.id,e]));
 const corrections=new Map((Array.isArray(review)?review:review.corrections||[]).map(r=>[r.id,r]));
 for(const [id,old] of before){
  const next=after.get(id);if(!next)throw Error('Existing entry removed: '+id);
  if(entryPath(old)!==entryPath(next))throw Error('Existing research URL changed: '+id);
  const paragraphs=new Set(next.sections.flatMap(s=>s.paragraphs)),missing=old.sections.flatMap(s=>s.paragraphs).filter(p=>!paragraphs.has(p));
  if(missing.length){const correction=corrections.get(id);if(!correction||correction.before_sha256!==digest(old)||typeof correction.reason!=='string'||correction.reason.trim().length<5||missing.some(p=>!correction.removed_paragraphs?.includes(p)))throw Error('Unreviewed historical paragraph removal: '+id);}
 }
 for(const old of baseline.projects)if(!candidate.projects.some(p=>p.id===old.id))throw Error('Existing project removed: '+old.id);
 for(const old of baseline.topics||[])if(!candidate.topics?.some(p=>p.id===old.id))throw Error('Existing topic removed: '+old.id);
 if(renderHome(baseline,origin)!==renderHome(candidate,origin))throw Error('Content changes must not change homepage markup');
 const changed=candidate.knowledge.entries.filter(e=>!before.has(e.id)||digest(e)!==digest(before.get(e.id))),documents=searchDocuments(candidate.knowledge,{snapshot:candidate});
 const indexed=new Map(documents.map(d=>[d.path,d]));
 for(const e of candidate.knowledge.entries)if(indexed.get(entryPath(e))?.id!==e.id)throw Error('Missing full search entry: '+e.id);
 for(const e of changed){
  const route=entryPath(e),html=renderKnowledge(candidate.knowledge,new URL(origin+route),origin),markdown=renderKnowledgeMarkdown(candidate.knowledge,new URL(origin+route+'index.md'),origin);
  if(!html||!markdown||!html.includes('<h1>'+esc(e.title)+'</h1>')||e.sections.some(s=>s.paragraphs.some(p=>!html.includes(esc(p)))))throw Error('Incomplete readable body: '+e.id);
  if(!rankResearch(documents,e.title).some(r=>r.doc.id===e.id))throw Error('New material not searchable: '+e.id);
 }
 return {status:changed.length||digest(baseline)!==digest(candidate)?'VALIDATED_REVIEW_READY':'VALIDATED_NO_CHANGE',baseline_sha256:digest(baseline),candidate_sha256:digest(candidate),entries:candidate.knowledge.entries.length,projects:candidate.projects.length,added:changed.filter(e=>!before.has(e.id)).map(e=>e.id),updated:changed.filter(e=>before.has(e.id)).map(e=>e.id),all_existing_urls_preserved:true,homepage_unchanged_by_data:true,all_entries_searchable:true,changed_bodies_checked:changed.length,capacity:{remaining_entries:5000-candidate.knowledge.entries.length,reader_characters:serialized.length,remaining_reader_characters:8388608-serialized.length},published:false};
}
async function main(){
 const args=process.argv.slice(2),value=(name)=>{const i=args.indexOf(name);return i>=0?args[i+1]:undefined;},candidatePath=value('--candidate')||'../../outputs/public-research-data.json',baselinePath=value('--baseline');
 const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
 const candidate=read(candidatePath);let baseline;
 if(baselinePath)baseline=read(baselinePath);else{const response=await fetch(origin+'/research.json',{signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('Cannot read live baseline: '+response.status);baseline=await response.json();}
 const report=validateContentUpdate(baseline,candidate,value('--review')?read(value('--review')):[]);
 const coordination=fs.existsSync('private/publication-coordination.json')?read('private/publication-coordination.json'):null;
 report.checked_at=new Date().toISOString();report.publication_window=coordination?.status||'UNSET';report.may_publish_data=coordination?.status==='OPEN';
 fs.mkdirSync('private',{recursive:true});fs.writeFileSync('private/content-intake-latest.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({...report,added:report.added.length,updated:report.updated.length}));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(error=>{console.error(error.message);process.exitCode=1;});
