import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {renderHome} from '../lib/home-page.js';
const base=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url)));
const origin='https://zhongshuderen-research.netlify.app';
test('home is a searchable introduction with second-level entry and real visitor footer',()=>{
 const html=renderHome(base,origin);
 assert(html.includes('action="/library/" method="get"'));
 assert(html.includes('name="q"'));assert(html.includes('href="/areas/loan-price/"'));
 assert(html.includes('SearchAction'));assert(html.includes('13359246679'));assert(html.includes('id="visitor-total-summary"'));assert(!html.includes('id="visitor-stats"'));
 assert.equal(html.split('<h1').length-1,1);
 for(const forbidden of ['latest-journal','reading-card','project-grid','draft-data','交互草稿','12 条'])assert(!html.includes(forbidden),forbidden);
});
test('research additions and corrections never inject summaries into the homepage',()=>{
 const updated=structuredClone(base);updated.checked_at='2099-01-01T00:00:00Z';
 updated.knowledge.entries.push({id:'research-log-20990101',summary:'<img src=x onerror=bad()>',research_date:'2099-01-01'});
 updated.projects[0].summary='New research result should remain in deeper pages';
 assert.equal(renderHome(base,origin),renderHome(updated,origin));
});
