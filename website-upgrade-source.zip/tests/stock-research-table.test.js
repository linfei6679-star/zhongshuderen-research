import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {stockReports,selectStockGroups,renderStockBoard,compareStockReports} from '../lib/stock-research-table.js';
import {renderKnowledge,renderKnowledgeMarkdown,entryPath} from '../lib/knowledge-library.js';
import {renderHome} from '../lib/home-page.js';
import {createReader} from '../lib/public-research-reader.js';
const data=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8')),origin='https://zhongshuderen-research.netlify.app';
const reports=stockReports(data.knowledge);
test('existing approved report dates and reasons feed the table without an extra data copy',()=>{
 const published=data.knowledge.entries.filter(e=>e.category==='stock-results');assert.equal(reports.length,published.length);
 for(const r of reports){assert(r.updatedMs>0,r.id);assert(r.reason.length>10);assert(['loan','price'].includes(r.topic));assert(r.entry.sections.some(s=>s.paragraphs.includes('报告最新更新日期：'+r.updated)));}
});
test('one stock groups its distinct business matters, while latest source dates break update-time ties',()=>{
 const all=selectStockGroups(reports,{topic:'loan',level:'all'});assert.equal(new Set(all.map(g=>g.code)).size,all.length);
 const yunnan=all.find(g=>g.code==='002053');assert.equal(yunnan.cases.length,3);
 for(let i=1;i<all.length;i++)assert(compareStockReports(all[i-1],all[i])<=0);
 const tied=selectStockGroups([{...reports[0],id:'fixture-a',code:'999998',topic:'loan',updatedMs:100,sourceMs:10},{...reports[0],id:'fixture-b',code:'999999',topic:'loan',updatedMs:100,sourceMs:20}],{topic:'loan',level:'all'});
 assert.equal(tied[0].code,'999999');
});
test('an unknown report update date is not replaced by completion or publication time',()=>{
 const e=structuredClone(reports[0].entry);const dates=e.sections.find(s=>s.heading==='日期与信息覆盖期间');dates.paragraphs=dates.paragraphs.map(p=>p.startsWith('报告最新更新日期：')?'报告最新更新日期：未知':p);
 const r=stockReports({entries:[e]})[0];assert.equal(r.updatedMs,0);assert.equal(r.updated,'未知');assert(r.completed);
});
test('focus selection retains opposing cases of a matched company and does not mechanically add conviction',()=>{
 const a={...reports[0],code:'999999',focus:true,direction:'潜在受益'},b={...reports[0],id:'opposite-case',code:'999999',focus:false,direction:'潜在受损'};
 const groups=selectStockGroups([a,b],{level:'focus'});assert.equal(groups.length,1);assert.equal(groups[0].cases.length,2);assert.deepEqual(new Set(groups[0].directions),new Set(['潜在受益','潜在受损']));
});
test('search, date and level filters preserve all evidence routes',()=>{
 const all=selectStockGroups(reports,{topic:'price',q:'000930',level:'all'});assert.equal(all.length,1);assert.equal(all[0].name,'中粮科技');
 assert(selectStockGroups(reports,{topic:'price',level:'all'}).length>selectStockGroups(reports,{topic:'price',level:'focus'}).length);
 assert.equal(selectStockGroups(reports,{date:'1900-01-01',level:'all'}).length,0);
 const html=renderStockBoard(data.knowledge,new URL(origin+'/library/stock-research-price-mapping/'),origin,'price');
 assert.match(html,/<table class="stock-table">/);assert.match(html,/id="stock-search"/);assert.match(html,/id="stock-level"/);
 for(const r of reports.filter(r=>r.topic==='price'))assert(html.includes('/library/'+r.id+'/'));
});
test('homepage uses compact project links, and existing project URLs preserve original scope text',()=>{
 const home=renderHome(data,origin);assert(home.includes('href="/areas/loan-price/"'));assert(!home.includes('href="/library/stock-research-loan-expansion/"'));assert(!home.includes('href="/library/stock-research-price-mapping/"'));
 assert(!home.includes('stock-table-data'));assert(!home.includes('latest-journal'));
 for(const id of ['stock-research-results','stock-research-loan-expansion','stock-research-price-mapping']){
  const e=data.knowledge.entries.find(e=>e.id===id),html=renderKnowledge(data.knowledge,new URL(origin+'/library/'+id+'/'),origin);assert(html.includes('<h1>'+e.title+'</h1>'));for(const s of e.sections)for(const p of s.paragraphs)assert(html.includes(p.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')),id);
 }
});

test('only the two project boards receive one compact registered visual, outside their table rows',()=>{
 for(const [topic,visual] of [['loan','loan-expansion'],['price','price-mapping']]){
  const html=renderStockBoard(data.knowledge,new URL(origin+'/'),origin,topic);
  assert.equal((html.match(/data-visual=/g)||[]).length,1);
  assert.match(html,new RegExp('data-visual="visual-'+visual+'-v1"'));
  assert.match(html,/<header class="stock-board-head stock-board-head--visual">/);
  assert.match(html,/<link rel="stylesheet" href="\/design-library\/visuals\.css\?v=/);
  assert.doesNotMatch(html.match(/<tbody id="stock-rows">([\s\S]*?)<\/tbody>/)[1],/<img|data-visual=/);
 }
 const all=renderStockBoard(data.knowledge,new URL(origin+'/'),origin,'all');
 assert.doesNotMatch(all,/data-visual=|\/design-library\/visuals\.css/);
 assert.doesNotMatch(renderHome(data,origin),/data-visual=|\/design-library\/visuals\.css/);
});

test('approved stock reports each use one topic visual without changing evidence, dates, URLs or Markdown',()=>{
 const before=JSON.stringify(data);
 for(const r of reports){
  const path=entryPath(r.entry),html=renderKnowledge(data.knowledge,new URL(origin+path),origin);
  assert.equal((html.match(/data-visual=/g)||[]).length,1,r.id);
  assert.match(html,new RegExp('data-visual="visual-'+(r.topic==='loan'?'loan-expansion':'price-mapping')+'-v1"'));
  assert.match(html,/主题插画 .*不代表实测数据/);
  assert(html.includes('href="'+origin+path+'"'));
  const escaped=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  assert(html.includes(escaped(r.entry.research_date)));
  for(const s of r.entry.sections)for(const p of s.paragraphs)assert(html.includes(escaped(p)),r.id);
  const markdown=renderKnowledgeMarkdown(data.knowledge,new URL(origin+path+'index.md'),origin);
  assert.doesNotMatch(markdown,/<img|data-visual=|visuals\/collection/);
 }
 for(const e of [data.knowledge.entries.find(e=>e.kind==='stock'),data.knowledge.entries.find(e=>e.category!=='stock-results'&&e.kind==='topic')]){
  const html=renderKnowledge(data.knowledge,new URL(origin+entryPath(e)),origin);
  assert.doesNotMatch(html,/data-visual=|\/design-library\/visuals\.css/);
 }
 const withdrawn={...reports[0].entry,status:reports[0].entry.status+'；批准失效，等待重新复核'};
 const changed={...data.knowledge,entries:data.knowledge.entries.map(e=>e.id===withdrawn.id?withdrawn:e)};
 assert.doesNotMatch(renderKnowledge(changed,new URL(origin+entryPath(withdrawn)),origin),/data-visual=|\/design-library\/visuals\.css/);
 assert.equal(JSON.stringify(data),before);
});

test('the Edge reader shares the illustrated report renderer while its JSON remains unchanged',async()=>{
 const handler=createReader({seed:data,origin}),context={next:()=>new Response('fallback',{status:404})};
 const response=await handler(new Request(origin+entryPath(reports[0].entry)),context);
 assert.equal(response.status,200);assert.equal(((await response.text()).match(/data-visual=/g)||[]).length,1);
 const snapshot=await handler(new Request(origin+'/research.json'),context);
 assert.deepEqual(await snapshot.json(),data);
});
