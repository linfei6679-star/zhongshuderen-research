(()=>{
 const area=document.querySelector('[data-fish-scene]'),raw=document.getElementById('fish-scene-data');
 const params=new URLSearchParams(location.search);if(params.get('motion')==='off')document.getElementById('site')?.classList.add('reduced');
 const question=params.get('question');if(question&&location.pathname.startsWith('/ask')){const field=document.querySelector('textarea[name="question"]');if(field&&!field.value)field.value=question.slice(0,200);}
 if(!area||!raw)return;
 let data;try{data=JSON.parse(raw.textContent);}catch{return;}if(!data.length)return;
 const links=[...area.querySelectorAll('[data-fish]')],line=document.getElementById('live-fishing-line'),hook=document.getElementById('live-fishing-hook');
 const reduce=matchMedia('(prefers-reduced-motion: reduce)'),mobile=matchMedia('(max-width:760px)');
 let paused=false,last=0,elapsed=0,focus=false;
 area.addEventListener('pointerenter',()=>paused=true);area.addEventListener('pointerleave',()=>{if(!focus)paused=false;});area.addEventListener('focusin',()=>{focus=true;paused=true;});area.addEventListener('focusout',()=>{focus=false;paused=false;});
 const lerp=(a,b,t)=>a+(b-a)*t,ease=t=>t*t*(3-2*t),quad=(a,b,c,t)=>[(1-t)*(1-t)*a[0]+2*(1-t)*t*b[0]+t*t*c[0],(1-t)*(1-t)*a[1]+2*(1-t)*t*b[1]+t*t*c[1]];
 function frame(now){
  const dt=last?Math.min(64,now-last):0;last=now;
  const stopped=reduce.matches||mobile.matches||document.getElementById('site')?.classList.contains('reduced');
  if(!paused&&!stopped&&!document.hidden)elapsed+=dt;
  const segment=9000,selected=Math.floor(elapsed/segment)%data.length,p=elapsed%segment/segment;
  for(let i=0;i<links.length;i++){
   let [x,y]=data[i].start,scale=1,opacity=1;
   if(!stopped&&i===selected){
    if(p>.25&&p<.62){[x,y]=quad(data[i].start,[1190,385],[1200,310],ease((p-.25)/.37));}
    else if(p>=.62&&p<.88){[x,y]=quad([1200,310],[1400,240],[1545,360],ease((p-.62)/.26));scale=lerp(1,.35,ease((p-.62)/.26));}
    else if(p>=.88){x=1545;y=lerp(360,414,ease((p-.88)/.12));scale=lerp(.35,.18,ease((p-.88)/.12));opacity=p>.98?0:1;}
   }
   links[i].style.left=x/1672*100+'%';links[i].style.top=y/941*100+'%';links[i].style.transform='translate(-50%,-50%) scale('+scale+')';links[i].style.opacity=String(opacity);
   if(i===selected){let hx=x-(links[i].offsetWidth/area.clientWidth*1672)*.44*scale,hy=y+2;if(p<.22&&!stopped){const t=ease(p/.22);hx=lerp(1158,hx,t);hy=lerp(285,hy,t);}line?.setAttribute('d','M1158 262 Q'+lerp(1158,hx,.5)+' '+(hy-20)+' '+hx+' '+hy);hook?.setAttribute('d','M'+hx+' '+(hy-8)+'q-9 17 2 13q8-2 4-9');if(line)line.style.opacity=stopped||p>.96?'0':'1';if(hook)hook.style.opacity=stopped||p>.96?'0':'1';}
  }
  requestAnimationFrame(frame);
 }
 requestAnimationFrame(frame);
})();
