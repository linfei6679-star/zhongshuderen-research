import {validateVisitorTotals} from '../lib/visitor-totals.js';
const VISITOR_WINDOW_MS=24*60*60*1000;
const VISITOR_RETENTION_MS=7*VISITOR_WINDOW_MS;
const VISITOR_HEADERS={'Cache-Control':'no-store','Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff'};
const NON_HTML_ASSET=/\.(?:json|jsonl|map|md|txt|xml|js|mjs|cjs|css|svg|png|jpe?g|webp|gif|ico|avif|woff2?|ttf|otf|eot|pdf|zip|gz|br|mp[34]|webm|wav)$/i;
function countablePageview(request,response){
 if(request.method!=='GET'||!response||response.status!==200||!/^text\/html(?:\s*;|$)/i.test(response.headers.get('Content-Type')||''))return false;
 const path=new URL(request.url).pathname;
 return !NON_HTML_ASSET.test(path)&&!/^\/(?:assets|visuals|api)\//.test(path);
}
function visitorDatabase(env){
 const db=env?.QUESTIONS_DB;
 if(!db||typeof db.prepare!=='function'||typeof db.batch!=='function')throw Error('visitor-database-unavailable');
 return db;
}
async function visitorIpHash(ip){
 // Stable across hours: rotating per-hour hashes would incorrectly inflate
 // COUNT(DISTINCT) over the 24-hour window. The hash remains private in D1.
 const value=new TextEncoder().encode('zhongshuderen.website.analytics.ip.v1\0'+ip.trim().toLowerCase());
 return [...new Uint8Array(await crypto.subtle.digest('SHA-256',value))].map(byte=>byte.toString(16).padStart(2,'0')).join('');
}
// Call only after creating the actual page response:
// ctx.waitUntil(recordPageview(request, env, ctx, response)).
// The fourth argument prevents accidental counting of failed or non-HTML requests.
export async function recordPageview(request,env,ctx,response){
 try{
  if(!countablePageview(request,response))return {recorded:false,reason:'NOT_A_PAGEVIEW'};
  const ip=request.headers.get('CF-Connecting-IP');
  if(!ip||!/^[0-9a-f:.]{3,64}$/i.test(ip.trim()))return {recorded:false,reason:'PLATFORM_IP_UNAVAILABLE'};
  const db=visitorDatabase(env),observed=Date.now(),ipHash=await visitorIpHash(ip);
  const results=await db.batch([
   db.prepare('DELETE FROM website_pageviews WHERE viewed_at <= ?').bind(observed-VISITOR_RETENTION_MS),
   db.prepare('INSERT INTO website_pageviews (viewed_at,ip_hash) VALUES (?,?)').bind(observed,ipHash),
   db.prepare('INSERT OR IGNORE INTO website_visitor_totals (ip_hash,first_seen_at) VALUES (?,?)').bind(ipHash,observed)
  ]);
  if(!Array.isArray(results)||results.length!==3||results.some(row=>row.success!==true)||results[1].meta?.changes!==1)throw Error('pageview-write-unconfirmed');
  return {recorded:true};
 }catch{return {recorded:false,reason:'ANALYTICS_UNAVAILABLE'};}
}

export async function readVisitorStats(request,env){
 if(!['GET','HEAD'].includes(request.method))return new Response(JSON.stringify({error:'METHOD_NOT_ALLOWED'}),{status:405,headers:{...VISITOR_HEADERS,Allow:'GET, HEAD'}});
 try{
  const db=visitorDatabase(env),observed=Date.now();
  // The interval is (observed - 24 hours, observed]. Events at the old boundary
  // or in the future are excluded. Distinct hashes are counted across all hours.
  const results=await db.batch([
   db.prepare('DELETE FROM website_pageviews WHERE viewed_at <= ?').bind(observed-VISITOR_RETENTION_MS),
   db.prepare('SELECT COUNT(DISTINCT ip_hash) AS unique_visitors,COUNT(*) AS pageviews FROM website_pageviews WHERE viewed_at > ? AND viewed_at <= ?').bind(observed-VISITOR_WINDOW_MS,observed)
  ]);
  if(!Array.isArray(results)||results.length!==2||results.some(row=>row.success!==true)||results[1].results?.length!==1)throw Error('analytics-read-unconfirmed');
  const row=results[1].results[0];
  if(!Number.isSafeInteger(row.unique_visitors)||!Number.isSafeInteger(row.pageviews)||row.unique_visitors<0||row.pageviews<row.unique_visitors)throw Error('invalid-analytics-counts');
  const snapshot={schema_version:1,observed_at:new Date(observed).toISOString(),window_hours:24,unique_visitors:row.unique_visitors,pageviews:row.pageviews,source:'Cloudflare D1 Website Analytics',method:'unique_ip'};
  return new Response(request.method==='HEAD'?null:JSON.stringify(snapshot),{headers:VISITOR_HEADERS});
 }catch{return new Response(request.method==='HEAD'?null:JSON.stringify({error:'VISITOR_STATS_UNAVAILABLE'}),{status:503,headers:VISITOR_HEADERS});}
}

export async function readVisitorTotals(request,env){
 if(!['GET','HEAD'].includes(request.method))return new Response(JSON.stringify({error:'METHOD_NOT_ALLOWED'}),{status:405,headers:{...VISITOR_HEADERS,Allow:'GET, HEAD'}});
 try{
  const db=visitorDatabase(env),observed=Date.now();
  const results=await db.batch([db.prepare('SELECT counted_since,history_scope,(SELECT COUNT(*) FROM website_visitor_totals WHERE first_seen_at>=m.counted_since AND first_seen_at<=?) AS unique_visitors FROM website_visitor_totals_meta m WHERE singleton=1 AND schema_version=1').bind(observed)]);
  if(results.length!==1||results[0].success!==true||results[0].results?.length!==1)throw Error('Persistent totals not initialized');
  const row=results[0].results[0],snapshot=validateVisitorTotals({schema_version:1,observed_at:new Date(observed).toISOString(),counted_since:new Date(row.counted_since).toISOString(),unique_visitors:row.unique_visitors,history_scope:row.history_scope,source:'Cloudflare D1 Website Analytics',method:'unique_ip'});
  return new Response(request.method==='HEAD'?null:JSON.stringify(snapshot),{headers:VISITOR_HEADERS});
 }catch{return new Response(request.method==='HEAD'?null:JSON.stringify({error:'VISITOR_TOTALS_UNAVAILABLE'}),{status:503,headers:VISITOR_HEADERS});}
}
