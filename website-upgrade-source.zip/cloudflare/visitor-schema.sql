-- Private analytics. No paths, cookies, user agents, identity or raw IP are stored.
-- Keep request-level timestamps so a rolling 24-hour boundary is exact.
CREATE TABLE IF NOT EXISTS website_pageviews (
  id INTEGER PRIMARY KEY,
  viewed_at INTEGER NOT NULL CHECK (viewed_at >= 0),
  ip_hash TEXT NOT NULL CHECK (length(ip_hash) = 64 AND ip_hash NOT GLOB '*[^0-9a-f]*')
);
-- A covering range index supports the exact time window and distinct-IP query.
CREATE INDEX IF NOT EXISTS website_pageviews_window_idx ON website_pageviews(viewed_at, ip_hash);
-- Seven-day expiration is enforced on subsequent record/read requests. It does
-- not require a cron job, and inactive periods do not fabricate new counts.

-- Persistent distinct visitor hashes. No request metadata or raw IP is stored.
CREATE TABLE IF NOT EXISTS website_visitor_totals (
 ip_hash TEXT PRIMARY KEY CHECK(length(ip_hash)=64 AND ip_hash NOT GLOB '*[^0-9a-f]*'),
 first_seen_at INTEGER NOT NULL CHECK(first_seen_at>=0)
);
CREATE TABLE IF NOT EXISTS website_visitor_totals_meta (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),schema_version INTEGER NOT NULL CHECK(schema_version=1),
 counted_since INTEGER NOT NULL CHECK(counted_since>=0),
 history_scope TEXT NOT NULL CHECK(history_scope IN ('verified_retained_history','new_measurement_epoch'))
);
