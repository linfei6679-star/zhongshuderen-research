import fs from 'node:fs';
import crypto from 'node:crypto';
import {validatePublicSnapshot} from '../lib/public-research-reader.js';
import {entryPath} from '../lib/knowledge-library.js';
import {publicationOrigin as origin} from '../lib/publication-origin.js';
const indexId='research-updates';
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const args=process.argv.slice(2),apply=args.includes('--apply'),initialize=args.includes('--initialize');
const file='../../outputs/public-research-data.json';
const candidate=validatePublicSnapshot(JSON.parse(fs.readFileSync(file,'utf8')));
const response=await fetch(origin+'/research.json',{signal:AbortSignal.timeout(20000)});
if(!response.ok)throw Error('Cannot read current publication baseline');
const baseline=validatePublicSnapshot(await response.json());
if(Date.parse(candidate.checked_at)<Date.parse(baseline.checked_at))throw Error('Shared input is older than public data');
const before=new Map(baseline.knowledge.entries.map(e=>[e.id,e]));
for(const e of baseline.knowledge.entries)if(!candidate.knowledge.entries.some(n=>n.id===e.id))throw Error('Existing public entry is missing from candidate');
const changed=candidate.knowledge.entries.filter(e=>e.id!==indexId&&(!before.has(e.id)||hash(e)!==hash(before.get(e.id))));
const projects=candidate.projects.filter(p=>hash(p)!==hash(baseline.projects.find(x=>x.id===p.id)));
let index=candidate.knowledge.entries.find(e=>e.id===indexId);
if(!changed.length&&!projects.length&&(!initialize||index)){console.log(JSON.stringify({status:'NO_NEW_RELEASE_RECORD',changed_entries:0,homepage_changed:false,written:false}));process.exit(0);}
const now=new Date(),parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(p=>[p.type,p.value]));
const day=parts.year+'-'+parts.month+'-'+parts.day,time=parts.hour+':'+parts.minute;
if(!index){
 index={id:indexId,name:'成果更新',title:'成果更新｜最近收录与持续研究',kind:'topic',category:'archives',summary:'按网站整理时间查看新接入和补充的研究，再进入对应项目和具体正文。原始材料日期、已验证结果与待验证判断分别保留。',research_date:'索引建立：'+day,status:'公开资料更新目录｜不把旧材料整理当作当日新成果',source_labels:['本站已公开研究资料、研究记录与项目目录'],keywords:['成果更新','最新研究','新收录','研究进展','项目成果'],sections:[],related:[]};candidate.knowledge.entries.push(index);
 const latest=candidate.knowledge.entries.filter(e=>/^research-log-\d{8}$/.test(e.id)).sort((a,b)=>b.id.localeCompare(a.id))[0];
 if(latest){index.sections.push({heading:'最近的研究记录',paragraphs:['从最近的正式研究记录开始，查看实际进展、已有结果与仍待验证的问题。'],links:[{label:latest.title,url:origin+entryPath(latest)}]});index.related.push(latest.id);}
 index.sections.push({heading:'按项目继续查看',paragraphs:['每份成果回到所属研究项目。跨主题的内容通过关联阅读连接，不重复铺在首页。'],links:candidate.projects.map(p=>({label:p.title,url:origin+'/research/'+p.id+'/'}))});
}
const added=changed.filter(e=>!before.has(e.id)),updated=changed.filter(e=>before.has(e.id));
if(changed.length||projects.length){
 const rows=[...changed.map(e=>({label:e.title,url:origin+entryPath(e)})),...projects.map(p=>({label:p.title+'｜项目进度',url:origin+'/research/'+p.id+'/'}))];
 const summary='本批新收录 '+added.length+' 页，补充 '+updated.length+' 页'+(projects.length?'，同步 '+projects.length+' 个项目进度':'')+'。这里的时间是网站整理时间；材料原始日期和研究状态请进入正文查看。';
 const sections=[];for(let i=0;i<rows.length;i+=25)sections.push({heading:day+' '+time+'｜收录与补充'+(rows.length>25?'（'+(Math.floor(i/25)+1)+'）':''),paragraphs:[summary],links:rows.slice(i,i+25)});
 index.sections.unshift(...sections);index.related=[...new Set([...changed.map(e=>e.id),...index.related])];
}
index.research_date='最近整理：'+day+' '+time+'（北京时间）；各材料原始日期见正文';candidate.checked_at=now.toISOString();validatePublicSnapshot(candidate);
const report={status:apply?'PREPARED_NOT_PUBLISHED':'PREVIEW_ONLY',at:now.toISOString(),baseline_sha256:hash(baseline),candidate_sha256:hash(candidate),index_id:indexId,added:added.map(e=>e.id),updated:updated.map(e=>e.id),projects:projects.map(p=>p.id),index_initialized:!before.has(indexId),homepage_changed:false};
if(apply){fs.writeFileSync(file,JSON.stringify(candidate)+'\n');fs.writeFileSync('content/knowledge.json',JSON.stringify(candidate.knowledge,null,2)+'\n');fs.writeFileSync('private/content-release-latest.json',JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({...report,added:added.length,updated:updated.length,projects:projects.length,written:apply}));
