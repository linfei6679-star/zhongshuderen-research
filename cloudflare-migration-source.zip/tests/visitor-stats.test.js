import test from 'node:test';
import assert from 'node:assert/strict';
import {initialVisitorStats,validateVisitorStats,visitorStatsText,createVisitorStatsReader,visitorStatsScript} from '../lib/visitor-stats.js';
test('only aggregate metrics accepted; zero is valid and stale records are labelled',()=>{
  assert.equal(validateVisitorStats({...initialVisitorStats,unique_visitors:0}).unique_visitors,0);
  assert.throws(()=>validateVisitorStats({...initialVisitorStats,ip:'private'}));
  assert.throws(()=>validateVisitorStats({...initialVisitorStats,unique_visitors:-1}));
  assert.equal(validateVisitorStats({...initialVisitorStats,source:'Cloudflare D1 Website Analytics'}).method,'unique_ip');
  assert.throws(()=>validateVisitorStats({...initialVisitorStats,source:'unverified'}));
  const fixture={...initialVisitorStats,unique_visitors:2,observed_at:'2026-10-07T23:43:45Z'};
  assert.match(visitorStatsText(fixture,Date.parse(fixture.observed_at)),/最近24小时访客：2/);
  assert.match(visitorStatsText(initialVisitorStats,Date.parse(initialVisitorStats.observed_at)+37*3600000),/待更新/);
  assert.match(visitorStatsText(fixture),/2026-10-08 07:43/);
});
test('new data refreshes without deployment; failures and backward dates preserve last valid data',async()=>{
  let clock=Date.parse(initialVisitorStats.observed_at)+60000,calls=0,answer={...initialVisitorStats,unique_visitors:7,observed_at:new Date(clock).toISOString()};
  const reader=createVisitorStatsReader({now:()=>clock,fetcher:async()=>{calls++;return new Response(JSON.stringify(answer));}});
  const read=async()=>await (await reader(new Request('https://example.com/visitor-stats.json'))).json();
  assert.equal((await read()).unique_visitors,7);await read();assert.equal(calls,1);
  clock+=301000;answer={...initialVisitorStats};assert.equal((await read()).unique_visitors,7);
  clock+=301000;answer={...initialVisitorStats,ip:'must not leak'};assert.equal((await read()).unique_visitors,7);
  clock+=301000;answer={...initialVisitorStats,source:'Cloudflare D1 Website Analytics',unique_visitors:99,observed_at:new Date(clock).toISOString()};assert.equal((await read()).unique_visitors,7);
  assert.equal((await reader(new Request('https://example.com/visitor-stats.json',{method:'POST'}))).status,405);
  assert.equal(await (await reader(new Request('https://example.com/visitor-stats.json',{method:'HEAD'}))).text(),'');
});
test('footer client script parses and updates a text node',async()=>{
  const node={textContent:''},document={getElementById:()=>node};
  const script=visitorStatsScript.slice(8,-9);
  const execute=new Function('document','fetch',script);
  execute(document,async()=>({ok:true,json:async()=>({...initialVisitorStats,observed_at:new Date().toISOString(),unique_visitors:5})}));
  await new Promise(resolve=>setImmediate(resolve));
  assert.match(node.textContent,/访客：5/);
});
