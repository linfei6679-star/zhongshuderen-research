import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {handleQuestionSubmit} from '../cloudflare/question-submit.js';
// In-memory SQLite executes the real SQL. Fictional inputs never leave this test process.
const schema=fs.readFileSync(new URL('../cloudflare/questions-schema.sql',import.meta.url),'utf8');
function database(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(schema);
 return {sqlite,prepare(sql){return {bind(...args){return {sql,args};}};},async batch(statements){
  sqlite.exec('BEGIN');try{const result=statements.map(({sql,args})=>{const rows=sqlite.prepare(sql).all(...args);return {success:true,results:rows,meta:{changes:sqlite.prepare('SELECT changes() AS n').get().n}};});sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}
 }};
}
const origin='https://fictional-test.pages.dev';
function request(overrides={},headers={}){
 const fields={'form-name':'master-questions','nickname':'虚构测试读者','question-title':'虚构测试：如何整理资料','question':'本条仅为虚构测试数据，不应发送或公开。','contact-type':'email','reply-contact':'fictional@example.invalid','publication-consent':'yes','bot-field':'',...overrides};
 return new Request(origin+'/api/questions',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded','CF-Connecting-IP':'192.0.2.10',...headers},body:new URLSearchParams(fields)});
}
test('a receipt follows a real transaction and read-back; private contacts are stored only in D1',async()=>{
 const db=database();try{
  const response=await handleQuestionSubmit(request(),{QUESTIONS_DB:db});assert.equal(response.status,201);const receipt=await response.json();assert.equal(receipt.ok,true);assert.equal(receipt.duplicate,false);assert.match(receipt.receipt,/^qs_/);assert.equal(response.headers.get('X-Submission-Id'),receipt.receipt);assert(!JSON.stringify(receipt).includes('example.invalid'));
  const row=db.sqlite.prepare('SELECT * FROM question_submissions').get();assert.equal(row.id,receipt.receipt);assert.equal(row.reply_contact,'fictional@example.invalid');assert.equal(row.status,'received');assert.equal(row.publication_consent,1);assert.equal(row.retry_count,0);
  assert(!JSON.stringify(db.sqlite.prepare('SELECT * FROM question_rate_limits').all()).includes('192.0.2.10'));
  const again=await handleQuestionSubmit(request(),{QUESTIONS_DB:db});assert.equal(again.status,200);const duplicate=await again.json();assert.equal(duplicate.receipt,receipt.receipt);assert.equal(duplicate.duplicate,true);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_submissions').get().n,1);assert.equal(db.sqlite.prepare('SELECT retry_count FROM question_submissions').get().retry_count,1);
 }finally{db.sqlite.close();}
});
test('native form receives a 303 only after successful storage',async()=>{
 const db=database();try{const response=await handleQuestionSubmit(request({}, {Accept:'text/html'}),{QUESTIONS_DB:db});assert.equal(response.status,303);assert.match(response.headers.get('Location'),/^\/ask\/received\/\?receipt=qs_/);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_submissions').get().n,1);}finally{db.sqlite.close();}
});
test('same-origin, consent, honeypot, schema and length gates reject without writing',async()=>{
 const db=database();try{
  for(const req of [request({}, {Origin:'https://external.invalid'}),request({}, {Origin:'null'}),request({'publication-consent':'no'}),request({'bot-field':'robot'}),request({unexpected:'field'}),request({question:'太短'}),request({'question-title':'测'.repeat(81)}),request({'reply-contact':'not-email'}),request({}, {'Content-Type':'application/json'})])assert((await handleQuestionSubmit(req,{QUESTIONS_DB:db})).status>=400);
  const absentOrigin=request();absentOrigin.headers.delete('Origin');assert.equal((await handleQuestionSubmit(absentOrigin,{QUESTIONS_DB:db})).status,403);
  const duplicate=new Request(origin+'/api/questions',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded'},body:'form-name=master-questions&form-name=other'});assert.equal((await handleQuestionSubmit(duplicate,{QUESTIONS_DB:db})).status,400);
  const malformed=new Request(origin+'/api/questions',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded'},body:'form-name=master-questions&question=%FF'});assert.equal((await handleQuestionSubmit(malformed,{QUESTIONS_DB:db})).status,400);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_submissions').get().n,0);
  const referer=request();referer.headers.delete('Origin');referer.headers.set('Referer',origin+'/ask/');assert.equal((await handleQuestionSubmit(referer,{QUESTIONS_DB:db})).status,201);
 }finally{db.sqlite.close();}
});
test('oversized bodies, failed bindings and unconfirmed read-backs never report success',async()=>{
 const db=database();try{
  assert.equal((await handleQuestionSubmit(request({}, {'Content-Length':'32769'}),{QUESTIONS_DB:db})).status,413);
  const big=new Request(origin+'/api/questions',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded'},body:'x'.repeat(32769)});assert.equal((await handleQuestionSubmit(big,{QUESTIONS_DB:db})).status,413);
  assert.equal((await handleQuestionSubmit(request(),{})).status,503);
  const bad={prepare:db.prepare,batch:async()=>{throw Error('fictional D1 failure');}};assert.equal((await handleQuestionSubmit(request(),{QUESTIONS_DB:bad})).status,503);
  const noReadback={prepare:db.prepare,batch:async statements=>{const result=await db.batch(statements);result[4].results=[];return result;}};assert.equal((await handleQuestionSubmit(request(),{QUESTIONS_DB:noReadback})).status,503);
  const retry=await handleQuestionSubmit(request(),{QUESTIONS_DB:db});assert.equal(retry.status,200);assert.equal((await retry.json()).duplicate,true);
 }finally{db.sqlite.close();}
});
test('hourly limits stop further inserts and expired rate keys are removed without deleting submissions',async()=>{
 const db=database();try{
  db.sqlite.prepare('INSERT INTO question_rate_limits VALUES (?,?,?)').run('expired-fictional',1,Date.now()-1);
  for(let i=0;i<5;i++)assert.equal((await handleQuestionSubmit(request({'question-title':'虚构测试 '+i}),{QUESTIONS_DB:db})).status,201);
  const limited=await handleQuestionSubmit(request({'question-title':'虚构测试超额'}),{QUESTIONS_DB:db});assert.equal(limited.status,429);assert(Number(limited.headers.get('Retry-After'))>0);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_submissions').get().n,5);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_rate_limits WHERE rate_key=?').get('expired-fictional').n,0);
 }finally{db.sqlite.close();}
});
test('no public read or admin operation is provided',async()=>{
 const response=await handleQuestionSubmit(new Request(origin+'/api/questions'),{});assert.equal(response.status,405);assert.equal(response.headers.get('Allow'),'POST');assert.equal(response.headers.get('Cache-Control'),'no-store');
});
test('the global hourly cap also limits submissions distributed across client hashes',async()=>{
 const db=database();try{
  for(let i=0;i<40;i++)assert.equal((await handleQuestionSubmit(request({'question-title':'虚构全站配额测试 '+i},{'CF-Connecting-IP':'192.0.2.'+(i+20)}),{QUESTIONS_DB:db})).status,201);
  const limited=await handleQuestionSubmit(request({'question-title':'虚构全站配额测试超限'},{'CF-Connecting-IP':'192.0.2.100'}),{QUESTIONS_DB:db});assert.equal(limited.status,429);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_submissions').get().n,40);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM question_rate_limits').get().n,41);
 }finally{db.sqlite.close();}
});
