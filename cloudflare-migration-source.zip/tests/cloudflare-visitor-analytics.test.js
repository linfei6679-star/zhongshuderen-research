import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {recordPageview,readVisitorStats} from '../cloudflare/visitor-analytics.js';
const schema=fs.readFileSync(new URL('../cloudflare/visitor-schema.sql',import.meta.url),'utf8');
const HOUR=3600000,DAY=24*HOUR;
function database(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(schema);
 return {sqlite,prepare(sql){return {bind(...args){return {sql,args};}};},async batch(statements){
  sqlite.exec('BEGIN');try{const result=statements.map(({sql,args})=>({success:true,results:sqlite.prepare(sql).all(...args),meta:{changes:sqlite.prepare('SELECT changes() AS n').get().n}}));sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}
 }};
}
const page=(ip='192.0.2.10',path='/ask/',method='GET')=>new Request('https://fictional-test.pages.dev'+path,{method,headers:{'CF-Connecting-IP':ip,'User-Agent':'fictional-test-agent','Cookie':'fictional=private'}});
const html=(status=200)=>new Response('<p>虚构测试页面</p>',{status,headers:{'Content-Type':'text/html; charset=utf-8'}});
const statsRequest=(method='GET')=>new Request('https://fictional-test.pages.dev/visitor-stats.json',{method});

test('only actual successful HTML GET responses count; no raw identifiers are retained',async()=>{
 const db=database(),env={QUESTIONS_DB:db};try{
  for(const [request,response] of [[page(),html()],[page('192.0.2.10','/ask/received/?receipt=fictional'),html()],[page('192.0.2.10','/design-library/'),html()]])assert.equal((await recordPageview(request,env,{},response)).recorded,true);
  for(const [request,response] of [[page('192.0.2.10','/ask/','HEAD'),html()],[page('192.0.2.10','/ask/','POST'),html()],[page(),html(404)],[page(),html(500)],[page(),new Response('{}',{headers:{'Content-Type':'application/json'}})],[page('192.0.2.10','/visitor-stats.json'),html()],[page('192.0.2.10','/library/test/index.md'),html()],[page('192.0.2.10','/visuals/test'),html()],[page(),undefined]])assert.equal((await recordPageview(request,env,{},response)).recorded,false);
  const rows=db.sqlite.prepare('SELECT * FROM website_pageviews').all();assert.equal(rows.length,3);for(const row of rows){assert.deepEqual(Object.keys(row),['id','viewed_at','ip_hash']);assert.match(row.ip_hash,/^[a-f0-9]{64}$/);}
  const saved=JSON.stringify(rows);for(const privateValue of ['192.0.2.10','fictional-test-agent','fictional=private','/ask/'])assert(!saved.includes(privateValue));
 }finally{db.sqlite.close();}
});
test('rolling 24-hour UV deduplicates across hours and PV has exact millisecond boundaries',async t=>{
 const db=database(),env={QUESTIONS_DB:db};const observed=Date.parse('2026-10-13T10:00:00.000Z');let tick=observed;t.mock.method(Date,'now',()=>tick);
 try{
  for(const [at,ip] of [[observed-DAY-1,'192.0.2.20'],[observed-DAY,'192.0.2.21'],[observed-DAY+1,'192.0.2.10'],[observed-HOUR,'192.0.2.10'],[observed,'192.0.2.30'],[observed+2,'192.0.2.40']]){tick=at;assert.equal((await recordPageview(page(ip),env,{},html())).recorded,true);}
  tick=observed;const response=await readVisitorStats(statsRequest(),env);assert.equal(response.status,200);const stats=await response.json();assert.deepEqual(stats,{schema_version:1,observed_at:new Date(observed).toISOString(),window_hours:24,unique_visitors:2,pageviews:3,source:'Cloudflare D1 Website Analytics',method:'unique_ip'});assert(!JSON.stringify(stats).includes('ip_hash'));
  tick=observed+1;const next=await(await readVisitorStats(statsRequest(),env)).json();assert.equal(next.unique_visitors,2);assert.equal(next.pageviews,2);
  const hashes=db.sqlite.prepare('SELECT ip_hash,COUNT(*) AS n FROM website_pageviews GROUP BY ip_hash').all();assert(hashes.some(row=>row.n===2));
 }finally{db.sqlite.close();}
});
test('seven-day expiry uses the time index and never removes current-window evidence',async t=>{
 const db=database(),env={QUESTIONS_DB:db},observed=Date.parse('2026-10-13T10:00:00.000Z');t.mock.method(Date,'now',()=>observed);
 try{
  const insert=db.sqlite.prepare('INSERT INTO website_pageviews (viewed_at,ip_hash) VALUES (?,?)');insert.run(observed-7*DAY,'a'.repeat(64));insert.run(observed-7*DAY+1,'b'.repeat(64));insert.run(observed-HOUR,'c'.repeat(64));
  const stats=await(await readVisitorStats(statsRequest(),env)).json();assert.equal(stats.pageviews,1);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM website_pageviews').get().n,2);
  const plan=db.sqlite.prepare('EXPLAIN QUERY PLAN SELECT COUNT(DISTINCT ip_hash),COUNT(*) FROM website_pageviews WHERE viewed_at > ? AND viewed_at <= ?').all(observed-DAY,observed);assert(plan.some(row=>row.detail.includes('website_pageviews_window_idx')));
 }finally{db.sqlite.close();}
});
test('analytics errors do not fail the page response and never manufacture a zero snapshot',async()=>{
 const broken={prepare(){throw Error('fictional D1 outage');},batch(){throw Error('fictional D1 outage');}};
 const response=html(),result=await recordPageview(page(),{QUESTIONS_DB:broken},{},response);assert.equal(result.recorded,false);assert.equal(response.status,200);assert.match(await response.text(),/虚构测试页面/);
 for(const env of [{},{QUESTIONS_DB:broken}]){const unavailable=await readVisitorStats(statsRequest(),env);assert.equal(unavailable.status,503);const data=await unavailable.json();assert.equal(data.error,'VISITOR_STATS_UNAVAILABLE');assert(!('unique_visitors' in data));assert(!('observed_at' in data));}
 const missingIp=new Request('https://fictional-test.pages.dev/');assert.equal((await recordPageview(missingIp,{}, {},html())).reason,'PLATFORM_IP_UNAVAILABLE');
});
test('successful empty database, HEAD and unsupported methods have distinct outcomes',async()=>{
 const db=database(),env={QUESTIONS_DB:db};try{
  const empty=await readVisitorStats(statsRequest(),env);assert.equal(empty.status,200);const data=await empty.json();assert.equal(data.pageviews,0);assert.equal(data.unique_visitors,0);assert.equal(Object.keys(data).length,7);
  const head=await readVisitorStats(statsRequest('HEAD'),env);assert.equal(head.status,200);assert.equal(await head.text(),'');assert.equal(head.headers.get('Cache-Control'),'no-store');
  assert.equal((await readVisitorStats(statsRequest('POST'),env)).status,405);
 }finally{db.sqlite.close();}
});
