-- Private intake only. There is deliberately no public reader/admin HTTP route.
-- Raw questions and contacts stay in this database until the owner reviews them.
CREATE TABLE IF NOT EXISTS question_submissions (
  id TEXT PRIMARY KEY,
  dedupe_key TEXT NOT NULL UNIQUE,
  content_hash TEXT NOT NULL,
  received_at TEXT NOT NULL,
  last_received_at TEXT NOT NULL,
  retry_count INTEGER NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
  form_name TEXT NOT NULL CHECK (form_name = 'master-questions'),
  nickname TEXT NOT NULL CHECK (length(nickname) <= 40),
  title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 80),
  question TEXT NOT NULL CHECK (length(question) BETWEEN 10 AND 2000),
  contact_type TEXT NOT NULL CHECK (contact_type IN ('email', 'wechat')),
  reply_contact TEXT NOT NULL CHECK (length(reply_contact) <= 120),
  publication_consent INTEGER NOT NULL CHECK (publication_consent = 1),
  status TEXT NOT NULL DEFAULT 'received' CHECK (status = 'received')
);
CREATE INDEX IF NOT EXISTS question_submissions_received ON question_submissions(received_at);
CREATE INDEX IF NOT EXISTS question_submissions_content ON question_submissions(content_hash);

-- Hour-scoped hashed client keys; no raw IP or user-agent is stored.
-- Rows expire within two hours and are removed on subsequent intake requests.
CREATE TABLE IF NOT EXISTS question_rate_limits (
  rate_key TEXT PRIMARY KEY,
  count INTEGER NOT NULL CHECK (count >= 1),
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS question_rate_limits_expiry ON question_rate_limits(expires_at);
