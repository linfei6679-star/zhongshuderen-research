// Private Cloudflare D1 intake. This module neither publishes questions nor answers them.
// Only platform-provided CF-Connecting-IP is used transiently for an hourly hash.
// Origin checks, size limits and modest quotas are basic abuse controls, not a CAPTCHA.
const FORM_FIELDS=new Set(['form-name','nickname','question-title','question','contact-type','reply-contact','publication-consent','bot-field']);
const REQUIRED_FIELDS=['form-name','question-title','question','contact-type','publication-consent'];
const MAX_BODY_BYTES=32768,CLIENT_HOURLY_LIMIT=5,GLOBAL_HOURLY_LIMIT=40;
const TEXT_ENCODER=new TextEncoder();
const NO_STORE={'Cache-Control':'no-store','Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'};
function errorResponse(status,code,message,extra={}){return new Response(JSON.stringify({ok:false,code,message}),{status,headers:{...NO_STORE,...extra}});}
function sameOrigin(request){
 const expected=new URL(request.url).origin,origin=request.headers.get('Origin'),referer=request.headers.get('Referer');
 if(request.headers.get('Sec-Fetch-Site')==='cross-site')return false;
 if(origin!==null&&origin!==expected)return false;
 if(referer!==null){try{if(new URL(referer).origin!==expected)return false;}catch{return false;}}
 return origin===expected||referer!==null;
}
async function readFormBody(request){
 const declared=request.headers.get('Content-Length');
 if(declared!==null&&(!/^\d+$/.test(declared)||Number(declared)>MAX_BODY_BYTES))throw Object.assign(Error('body-size'),{httpStatus:413});
 const reader=request.body?.getReader();if(!reader)return '';
 const decoder=new TextDecoder('utf-8',{fatal:true});let bytes=0,text='';
 try{while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>MAX_BODY_BYTES){await reader.cancel();throw Object.assign(Error('body-size'),{httpStatus:413});}text+=decoder.decode(value,{stream:true});}return text+decoder.decode();}
 finally{reader.releaseLock();}
}
function cleanText(value,max,{min=0,singleLine=false}={}){
 if(typeof value!=='string'||value.length>max||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)||(singleLine&&/[\r\n]/.test(value)))throw Error('invalid-field');
 const text=value.replace(/\r\n/g,'\n').trim();if(text.length<min)throw Error('invalid-field');return text;
}
function parseSubmission(text){
 if(/%(?![0-9a-f]{2})/i.test(text))throw Error('invalid-encoding');
 decodeURIComponent(text.replace(/\+/g,' ')); // Reject malformed percent-encoded UTF-8 before URLSearchParams replaces it.
 const fields=new URLSearchParams(text),seen=new Set();
 for(const [key] of fields){if(!FORM_FIELDS.has(key)||seen.has(key))throw Error('invalid-schema');seen.add(key);}
 if(REQUIRED_FIELDS.some(key=>!seen.has(key))||fields.get('form-name')!=='master-questions'||fields.get('publication-consent')!=='yes'||(fields.get('bot-field')||'').trim())throw Error('invalid-schema');
 const nickname=cleanText(fields.get('nickname')||'',40,{singleLine:true}),title=cleanText(fields.get('question-title'),80,{min:1,singleLine:true}),question=cleanText(fields.get('question'),2000,{min:10});
 const contactType=fields.get('contact-type'),contact=cleanText(fields.get('reply-contact')||'',120,{singleLine:true});
 if(!['email','wechat'].includes(contactType))throw Error('invalid-contact-type');
 if(contact&&contactType==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact))throw Error('invalid-contact');
 if(contact&&contactType==='wechat'&&!/^[a-z0-9_-]{3,120}$/i.test(contact))throw Error('invalid-contact');
 return {nickname,title,question,contactType,contact};
}
async function digest(text){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',TEXT_ENCODER.encode(text)))].map(byte=>byte.toString(16).padStart(2,'0')).join('');}

export async function handleQuestionSubmit(request,env,ctx){
 if(request.method!=='POST')return errorResponse(405,'METHOD_NOT_ALLOWED','这里只接收提交。',{Allow:'POST'});
 if(!sameOrigin(request))return errorResponse(403,'SAME_ORIGIN_REQUIRED','请从本站提问页提交，填写内容请先保留。');
 if(!/^application\/x-www-form-urlencoded(?:\s*;\s*charset\s*=\s*utf-8)?\s*$/i.test(request.headers.get('Content-Type')||''))return errorResponse(415,'UNSUPPORTED_CONTENT_TYPE','提交格式不支持，填写内容请先保留。');
 let input;try{input=parseSubmission(await readFormBody(request));}catch(error){return errorResponse(error.httpStatus||400,error.httpStatus===413?'BODY_TOO_LARGE':'INVALID_FORM','请检查问题长度、知情同意和联系方式；填写内容请先保留。');}
 if(!env?.QUESTIONS_DB||typeof env.QUESTIONS_DB.prepare!=='function'||typeof env.QUESTIONS_DB.batch!=='function')return errorResponse(503,'INTAKE_UNAVAILABLE','暂时不能确认收件，请保留内容后稍后重试。');
 const now=Date.now(),hour=Math.floor(now/3600000),receivedAt=new Date(now).toISOString(),expiry=(hour+2)*3600000;
 try{
  const hash=await digest(JSON.stringify(input)),dedupeKey=await digest(receivedAt.slice(0,10)+'|'+hash),id='qs_'+crypto.randomUUID();
  const ip=request.headers.get('CF-Connecting-IP')||'unknown';
  const clientKey='client:'+hour+':'+await digest(hour+'|'+ip),globalKey='global:'+hour;
  // Each batch is a single D1 transaction. The final SELECT is the required
  // read-back of the actual inserted/upserted row, not a fabricated receipt.
  const db=env.QUESTIONS_DB,rateSql='INSERT INTO question_rate_limits (rate_key,count,expires_at) VALUES (?,1,?) ON CONFLICT(rate_key) DO UPDATE SET count=MIN(question_rate_limits.count+1,?),expires_at=excluded.expires_at';
  const results=await db.batch([
   db.prepare('DELETE FROM question_rate_limits WHERE expires_at <= ?').bind(now),
   db.prepare(rateSql).bind(globalKey,expiry,GLOBAL_HOURLY_LIMIT+1),
   db.prepare('INSERT INTO question_rate_limits (rate_key,count,expires_at) SELECT ?,1,? WHERE (SELECT count FROM question_rate_limits WHERE rate_key=?) <= ? ON CONFLICT(rate_key) DO UPDATE SET count=MIN(question_rate_limits.count+1,?),expires_at=excluded.expires_at').bind(clientKey,expiry,globalKey,GLOBAL_HOURLY_LIMIT,CLIENT_HOURLY_LIMIT+1),
   db.prepare(`INSERT INTO question_submissions (id,dedupe_key,content_hash,received_at,last_received_at,retry_count,form_name,nickname,title,question,contact_type,reply_contact,publication_consent,status)
    SELECT ?,?,?,?,?,0,'master-questions',?,?,?,?,?,1,'received'
    WHERE (SELECT count FROM question_rate_limits WHERE rate_key=?) <= ? AND (SELECT count FROM question_rate_limits WHERE rate_key=?) <= ?
    ON CONFLICT(dedupe_key) DO UPDATE SET last_received_at=excluded.last_received_at,retry_count=question_submissions.retry_count+1`).bind(id,dedupeKey,hash,receivedAt,receivedAt,input.nickname,input.title,input.question,input.contactType,input.contact,globalKey,GLOBAL_HOURLY_LIMIT,clientKey,CLIENT_HOURLY_LIMIT),
   db.prepare('SELECT id,content_hash,received_at,last_received_at,retry_count FROM question_submissions WHERE dedupe_key=? LIMIT 1').bind(dedupeKey),
   db.prepare('SELECT rate_key,count FROM question_rate_limits WHERE rate_key IN (?,?)').bind(globalKey,clientKey)
  ]);
  if(!Array.isArray(results)||results.length!==6||results.some(result=>result.success!==true))throw Error('intake-transaction-unconfirmed');
  const rates=results[5].results||[],globalRate=rates.find(row=>row.rate_key===globalKey),clientRate=rates.find(row=>row.rate_key===clientKey);
  if(!globalRate)throw Error('intake-quota-unconfirmed');
  if(globalRate.count>GLOBAL_HOURLY_LIMIT||clientRate?.count>CLIENT_HOURLY_LIMIT)return errorResponse(429,'SUBMISSION_LIMIT','这一时段提交较多，请保留内容，稍后再试。',{'Retry-After':String(Math.max(1,Math.ceil(((hour+1)*3600000-now)/1000)))});
  if(!clientRate)throw Error('intake-quota-unconfirmed');
  const row=results[4].results?.[0];
  if(results[3].meta?.changes!==1||!row||row.content_hash!==hash||row.last_received_at!==receivedAt||!/^qs_[0-9a-f-]{36}$/.test(row.id)||!Number.isInteger(row.retry_count)||row.retry_count<0)throw Error('intake-readback-unconfirmed');
  const duplicate=row.id!==id,location='/ask/received/?receipt='+encodeURIComponent(row.id),accept=request.headers.get('Accept')||'';
  const receiptHeaders={...NO_STORE,Location:location,'X-Submission-Id':row.id};
  if(accept.includes('text/html')&&!accept.includes('application/json'))return new Response(null,{status:303,headers:receiptHeaders});
  return new Response(JSON.stringify({ok:true,receipt:row.id,received_at:row.received_at,duplicate}),{status:duplicate?200:201,headers:receiptHeaders});
 }catch{return errorResponse(503,'INTAKE_NOT_CONFIRMED','暂时不能确认收件，请保留填写内容后重试；重复提交会保留同一回执。');}
}
export async function handler(request,env,ctx){return handleQuestionSubmit(request,env,ctx);}
