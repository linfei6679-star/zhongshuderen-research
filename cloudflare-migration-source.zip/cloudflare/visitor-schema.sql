-- Private analytics. No paths, cookies, user agents, identity or raw IP are stored.
-- Keep request-level timestamps so a rolling 24-hour boundary is exact.
CREATE TABLE IF NOT EXISTS website_pageviews (
  id INTEGER PRIMARY KEY,
  viewed_at INTEGER NOT NULL CHECK (viewed_at >= 0),
  ip_hash TEXT NOT NULL CHECK (length(ip_hash) = 64 AND ip_hash NOT GLOB '*[^0-9a-f]*')
);
-- A covering range index supports the exact time window and distinct-IP query.
CREATE INDEX IF NOT EXISTS website_pageviews_window_idx ON website_pageviews(viewed_at, ip_hash);
-- Seven-day expiration is enforced on subsequent record/read requests. It does
-- not require a cron job, and inactive periods do not fabricate new counts.
