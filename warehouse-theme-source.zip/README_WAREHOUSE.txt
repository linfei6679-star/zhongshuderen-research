Complete reviewed theme-warehouse delta over round2. Reuses existing WebP crop windows. Includes precise per-group count wording. No research data, membership or private files included.
