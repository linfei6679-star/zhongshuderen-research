import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {warehouseThemes,renderWarehouseHero} from '../lib/warehouse-theme.js';
import {sections} from '../lib/section-registry.js';import {sectionQueryModel,sectionDocumentHref} from '../lib/section-query.js';
import {renderAreaRoute,renderAreaMarkdown} from '../lib/ink-experience.js';
import {renderKnowledge} from '../lib/knowledge-library.js';
import {renderQuestionWarehouse,emptyPublicQuestions} from '../lib/public-questions.js';
const source=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8')),origin='https://zhongshuderen.pages.dev',u=p=>new URL(p,origin);
const unesc=s=>s.replaceAll('&amp;','&').replaceAll('&quot;','"').replaceAll('&#39;',"'").replaceAll('&lt;','<').replaceAll('&gt;','>');
test('each scoped warehouse has an opaque theme crop, HTML title, attribution and real filtering shelves',()=>{
 for(const section of sections){const html=renderAreaRoute(source,u('/areas/'+section.id+'/search/'),origin);assert(html.includes('data-warehouse-theme="'+section.id+'"'));assert(html.includes('/visuals/liezi/'+section.asset));assert(html.includes('<h1>'+section.title+'</h1>'));assert(html.includes('灵感来源于《列子》'));assert(html.includes('clipPathUnits="userSpaceOnUse"'));assert(html.includes('warehouse-controls-box'));assert(html.includes('warehouse-shelf-group'));assert(!html.includes('data-fish-scene'));}
});
test('crop windows keep baked title/footer bands out of compact headers, without touching the source images',()=>{
 for(const [id,t]of Object.entries(warehouseThemes)){const [x,y,w,h]=t.crop;assert(x>=0&&y>=0&&x+w<=1672&&y+h<=941);if(t.asset!=='01-loan-price.webp'){assert(y>=150,id);assert(y+h<=850,id);}assert(fs.existsSync(new URL('../public/visuals/liezi/'+t.asset,import.meta.url)));}
 const escaped=renderWarehouseHero({id:'"bad',title:'<script>bad</script>'});assert(escaped.includes('data-warehouse-theme="library"'));assert(!escaped.includes('<script>bad</script>'));
});
test('visual grouping preserves original search order, all contextual URLs and HTML/Markdown page clamp',()=>{
 const url=u('/areas/quant-prediction/search/?q=回测&type=tools&page=999'),model=sectionQueryModel(source,url,'quant-prediction'),html=renderAreaRoute(source,url,origin),md=renderAreaMarkdown(source,u('/areas/quant-prediction/search/index.md?q=回测&type=tools&page=999'),origin);
 const hrefs=[...html.matchAll(/class="result-item" href="([^"]+)"/g)].map(m=>unesc(m[1]));assert.deepEqual(hrefs,model.rows.map(({doc})=>sectionDocumentHref(doc.path,model.state)));assert(md.includes('第 '+model.state.page+' / '+model.pages+' 页'));assert(html.includes('第 '+model.state.page+' / '+model.pages+' 页'));assert(model.rows.length>0);
});
test('global, stock and category aliases adopt the archive family while the study snapshot remains identical',()=>{
 const before=JSON.stringify(source);for(const path of ['/library/','/stocks/','/library/category/methods/','/library/category/stock-results/','/library/stock-research-loan-expansion/','/library/stock-research-price-mapping/']){const html=renderKnowledge(source.knowledge,u(path),origin,{snapshot:source});assert(html.includes('data-warehouse-theme='));assert(html.includes('warehouse-theme.css'));}assert.equal(JSON.stringify(source),before);
});
test('question warehouse has the same mountain-water family and preserves the real empty publication',()=>{
 const html=renderQuestionWarehouse(emptyPublicQuestions,u('/ask/search/?status=answered&page=999'),origin),md=renderQuestionWarehouse(emptyPublicQuestions,u('/ask/search/?status=answered&page=999'),origin,{markdown:true});assert(html.includes('08-ask.webp'));assert(html.includes('data-warehouse-theme="ask"'));assert(html.includes('name="status"'));assert(html.includes('当前条件下暂无公开问答'));assert(html.includes('第 1 / 1 页'));assert(md.includes('第 1 / 1 页'));assert.equal(emptyPublicQuestions.items.length,0);
});
test('searching again from a global category carries that category to the existing library query',()=>{
 const h=renderKnowledge(source.knowledge,u('/library/category/tools/?q=模型'),origin,{snapshot:source});
 const form=h.match(/<form class="search-form"[\s\S]*?<\/form>/)?.[0];assert(form);assert(form.includes('action="/library/"'));assert(form.includes('name="q"'));assert(form.includes('name="type" value="tools"'));
 const root=renderKnowledge(source.knowledge,u('/library/'),origin,{snapshot:source}).match(/<form class="search-form"[\s\S]*?<\/form>/)[0];assert(!root.includes('name="type"'));
});
