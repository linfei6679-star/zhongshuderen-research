import {sections,sectionPath} from '../lib/section-registry.js';
import {totalScopeText,validateVisitorTotals} from '../lib/visitor-totals.js';
import {decorateSectionDocument,renderSectionLanding} from '../lib/ink-experience.js';
import {createReader} from '../lib/public-research-reader.js';
import {searchDocuments} from '../lib/research-search.js';
import {renderHome} from '../lib/home-page.js';
import {renderAskMaster} from '../lib/ask-master-page.js';
import {createQuestionsReader} from '../lib/public-questions.js';
import {visitorStatsScript,validateVisitorStats,visitorStatsText} from '../lib/visitor-stats.js';
import {handleQuestionSubmit} from './question-submit.js';
import {recordPageview,readVisitorStats,readVisitorTotals} from './visitor-analytics.js';

const legacyOrigin='https://zhongshuderen-research.netlify.app';
const repositoryData='https://raw.githubusercontent.com/linfei6679-star/zhongshuderen-research/main/public-research-data.json';
const REFRESH_MS=30*60*1000;
const exactLegacy=legacyOrigin.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
export const cloudflareVisitorScript='<script id="cloudflare-visitor-stats">(()=>{const node=document.getElementById("visitor-stats");if(!node)return;const valid='+validateVisitorStats.toString()+';const format='+visitorStatsText.toString().replace('validateVisitorStats(value);','valid(value);')+';fetch("/visitor-stats.json",{signal:AbortSignal.timeout(6000),cache:"no-store"}).then(r=>{if(!r.ok)throw Error("STATS_UNAVAILABLE");return r.json();}).then(value=>{valid(value);if(value.source!=="Cloudflare D1 Website Analytics")throw Error("WRONG_SITE");node.textContent=format(value);node.dataset.statsLoaded="true";}).catch(()=>{if(node.dataset.statsLoaded!=="true")node.textContent="新站访客统计暂未读取，请稍后再看。";});})();</script>';

// Only presentation links change. Research JSON, quotations and external source
// addresses remain the reviewed source, so migration does not falsify provenance.
export function rewritePresentation(text,origin,type='text/html'){
 if(type.includes('markdown')||type.includes('text/plain'))return text.replace(new RegExp('(\\]\\()'+exactLegacy+'(?=[/#?]|\\))','g'),'$1');
 if(!type.includes('text/html'))return text;
 let output=text.replace(new RegExp('(<(?:meta|link)\\b[^>]*(?:content|href)=["\\\'])'+exactLegacy+'(?=[/#?"\\\'])','g'),'$1'+origin);
 output=output.replace(/\b(href|src|action)=(["'])([^"']*)\2/g,(all,name,quote,value)=>value===legacyOrigin?name+'='+quote+'/'+quote:value.startsWith(legacyOrigin+'/')||value.startsWith(legacyOrigin+'?')||value.startsWith(legacyOrigin+'#')?name+'='+quote+value.slice(legacyOrigin.length)+quote:all);
 output=output.replace(/(<script\b[^>]*type="application\/ld\+json"[^>]*>)([\s\S]*?)(<\/script>)/g,(all,start,json,end)=>{
  try{const rewrite=value=>typeof value==='string'&&(value===legacyOrigin||value.startsWith(legacyOrigin+'/'))?origin+value.slice(legacyOrigin.length):Array.isArray(value)?value.map(rewrite):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).map(([key,item])=>[key,rewrite(item)])):value;
   return start+JSON.stringify(rewrite(JSON.parse(json))).replace(/</g,'\\u003c')+end;
  }catch{return all;}
 });
 output=output.replace(visitorStatsScript,'').replace(/<script>\(\(\)=>\{const node=document\.getElementById\('visitor-stats'\)[\s\S]*?<\/script>/g,'');
 output=output.replace(/<script id="cloudflare-visitor-stats">[\s\S]*?<\/script>/g,'');
 output=output.replace(/<small\b[^>]*id="visitor-stats"[^>]*>[\s\S]*?<\/small>/g,'<small id="visitor-stats" style="display:block;margin:12px 0;color:#81716b;font-size:11px" title="当前入口滚动24小时成功HTML访问，按IP散列去重，可能含机器人；不是累计实名人数。">新站访客统计读取中……</small>'+cloudflareVisitorScript);
 // The original Netlify progressive-enhancement script still POSTs to /. Both
// the native form and JS are accepted by the same private submission handler.
 output=output.replace('data-netlify="true" netlify-honeypot="bot-field"','data-question-provider="cloudflare-d1" data-submit-endpoint="/api/questions"');
 return output;
}

async function readRepositoryDate(response){
 if(!response.ok)throw Error('Repository check failed');
 const reader=response.body?.getReader();if(!reader)throw Error('Streaming response unavailable');
 let prefix='',bytes=0;const decoder=new TextDecoder();
 try{
  while(bytes<8192){const item=await reader.read();if(item.done)break;const remaining=8192-bytes;const slice=item.value.subarray(0,remaining);bytes+=slice.byteLength;prefix+=decoder.decode(slice,{stream:true});
   const match=prefix.match(/^\s*\{\s*"schema_version"\s*:\s*1\s*,\s*"checked_at"\s*:\s*"([^"\\]{1,80})"/);
   if(match&&Number.isFinite(Date.parse(match[1])))return match[1];
  }
  throw Error('Reviewed data header unavailable');
 }finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}

export function createCloudflareWorker(config,{fetcher=fetch,now=Date.now,submit=handleQuestionSubmit,recordVisit=recordPageview,readStats=readVisitorStats}={}){
 const {seed,origin,notes=[],questions=[],publicQuestions,revision,builtAt}=config;
 if(!/^https:\/\/[a-z0-9.-]+$/.test(origin)||!/^[a-f0-9]{64}$/.test(revision))throw Error('Invalid release identity');
 // This work occurs during isolate startup, not during the first visitor query.
 const reader=createReader({seed,origin,notes,questions,dataUrl:'',fetcher,now});
 searchDocuments(seed.knowledge,{snapshot:seed,notes,questions});
 for(const section of sections)renderSectionLanding(seed,new URL(sectionPath(section.id),origin),origin);
 for(const topic of ['all','loan','price'])for(const level of ['focus','all'])renderSectionLanding(seed,new URL('/areas/loan-price/?'+new URLSearchParams({topic,level}),origin),origin);
 const questionReader=createQuestionsReader({seed:publicQuestions,origin,fetcher,now});
 let lastCheck=null,pendingCheck=null,repositoryCheckedAt=null,lastCheckSucceeded=null;
 async function checkForUpdates(){
  if(pendingCheck)return pendingCheck;
  const tick=now();if(lastCheck!==null&&tick-lastCheck<REFRESH_MS)return;
  lastCheck=tick;
  pendingCheck=(async()=>{try{
   const response=await fetcher(repositoryData+'?publication-check='+Math.floor(tick/REFRESH_MS),{headers:{Range:'bytes=0-8191',Accept:'application/json'},signal:AbortSignal.timeout(8000),redirect:'error'});
   repositoryCheckedAt=await readRepositoryDate(response);lastCheckSucceeded=true;
  }catch{lastCheckSucceeded=false;}finally{pendingCheck=null;}})();
  return pendingCheck;
 }
 function status(){return {schema_version:1,experience_version:'liezi-20261018-v2',mode:'validated_snapshot_deployment',research_checked_at:seed.checked_at,revision,built_at:builtAt,repository_checked_at:repositoryCheckedAt,repository_check_succeeded:lastCheckSucceeded,update_available:repositoryCheckedAt===null?null:Date.parse(repositoryCheckedAt)>Date.parse(seed.checked_at),update_action:'Website publisher validates the newest shared snapshot, rebuilds this same package and deploys it; no automatic full-library parse in visitor requests.',public_questions_mode:'github_refresh_with_validated_seed',visitor_scope:'current_cloudflare_html_rolling_24h'};}
 async function fetchRequest(request,env={},ctx={}){
  const url=new URL(request.url),pathname=url.pathname;
  const submitPath=['/api/questions','/api/questions/','/','/ask/received/','/ask/received'].includes(pathname);
  if(request.method==='POST'&&submitPath)return submit(request,env,ctx);
  if(pathname==='/api/questions'||pathname==='/api/questions/')return new Response('Method not allowed',{status:405,headers:{Allow:'POST'}});
  if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}});
  const isReceived=pathname==='/ask/received/'||pathname==='/ask/received';
  if(isReceived){
   const receipt=url.searchParams.get('receipt');let confirmed=false;
   if(/^qs_[0-9a-f-]{36}$/.test(receipt||'')){
    try{const row=await env.QUESTIONS_DB?.prepare('SELECT id FROM question_submissions WHERE id=? LIMIT 1').bind(receipt).first();confirmed=row?.id===receipt;}catch{/* Never claim intake from an unverified receipt. */}
   }
   if(!confirmed)return new Response(null,{status:303,headers:{Location:'/ask/?unconfirmed=1','Cache-Control':'no-store','X-Robots-Tag':'noindex'}});
  }
  if(typeof ctx.waitUntil==='function')ctx.waitUntil(checkForUpdates());
  const releaseHeaders={'X-Research-Revision':revision,'X-Research-Data-As-Of':seed.checked_at,'X-Research-Update-Mode':'validated-deployment','X-Content-Type-Options':'nosniff'};
  const respond=(body,type,statusCode=200,extra={})=>new Response(request.method==='HEAD'?null:body,{status:statusCode,headers:{...releaseHeaders,'Content-Type':type,...extra}});
  if(pathname==='/publication-status.json')return respond(JSON.stringify(status()),'application/json; charset=utf-8',200,{'Cache-Control':'no-store','X-Robots-Tag':'noindex'});
  if(pathname==='/visitor-totals.json')return readVisitorTotals(request,env);
  if(pathname==='/visitor-stats.json'){
   try{return await readStats(request,env);}catch{return respond(JSON.stringify({error:'STATS_UNAVAILABLE'}),'application/json; charset=utf-8',503,{'Cache-Control':'no-store','X-Robots-Tag':'noindex'});}
  }
  if(pathname==='/ask/sitemap.xml'){
   // Reuse exactly the public-question reader's validated, failure-preserving
   // cache. Questions can refresh independently of the fixed research build.
   const snapshotResponse=await questionReader(new Request(new URL('/questions.json',origin)),{next:()=>new Response(null,{status:404})});
   const data=await snapshotResponse.json();
   const xml='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>'+origin+'/ask/</loc></url><url><loc>'+origin+'/ask/new/</loc></url><url><loc>'+origin+'/ask/search/</loc></url>'+data.items.map(item=>'<url><loc>'+origin+'/ask/questions/'+item.id+'/</loc><lastmod>'+(item.answered_at||item.published_at)+'</lastmod></url>').join('')+'</urlset>';
   return respond(xml,'application/xml; charset=utf-8',200,{'Cache-Control':'public,max-age=60,s-maxage=300'});
  }
  const staticNext=async()=>{
   if(!env.ASSETS?.fetch)return new Response('Asset binding unavailable',{status:503});
   // ASSETS bypasses the Worker, including query strings and arbitrary paths.
   const assetUrl=new URL(request.url);if(pathname==='/api/research')assetUrl.pathname='/research.json';
   return env.ASSETS.fetch(assetUrl.href===request.url?request:new Request(assetUrl,request));
  };
  const response=isReceived?respond(renderAskMaster(origin,{submitted:true}),'text/html; charset=utf-8',200,{'Cache-Control':'no-store','X-Robots-Tag':'noindex'}):['/research.json','/api/research','/knowledge-index.json','/sitemap.xml','/llms.txt','/robots.txt'].includes(pathname)?await staticNext():pathname==='/'?respond(renderHome(seed,origin),'text/html; charset=utf-8'):
   await questionReader(request,{next:()=>reader(request,{next:staticNext})});
  const type=response.headers.get('Content-Type')||'';
  const headers=new Headers(response.headers);for(const [name,value] of Object.entries(releaseHeaders))headers.set(name,value);
  if(request.method==='HEAD')return new Response(null,{status:response.status,headers});
  if(!/text\/(?:html|markdown|plain)/.test(type))return new Response(response.body,{status:response.status,headers});
  let body=rewritePresentation(await response.text(),origin,type);
  if(type.includes('text/html'))body=decorateSectionDocument(body,url,seed);
  if(pathname==='/'&&type.includes('text/html')){try{const r=await readVisitorTotals(new Request(new URL('/visitor-totals.json',origin)),env);if(r.ok){const v=validateVisitorTotals(await r.json());body=body.replace('道场累计访客统计读取中……','已有'+v.unique_visitors.toLocaleString('zh-CN')+'人来过本道场。').replace('统计口径确认后显示；不会将每日访客相加为累计人数。',totalScopeText(v));}}catch{}}headers.delete('Content-Length');headers.delete('ETag');
  const finalResponse=new Response(body,{status:response.status,headers});
  if(request.method==='GET'&&response.status===200&&type.includes('text/html')&&typeof ctx.waitUntil==='function'){
   try{ctx.waitUntil(Promise.resolve().then(()=>recordVisit(request,env,ctx,finalResponse)).catch(()=>{}));}catch{/* Counting must never block delivery. */}
  }
  return finalResponse;
 }
 return {fetch:fetchRequest,status,checkForUpdates};
}
