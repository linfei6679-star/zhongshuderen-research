import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {renderAreaRoute,renderAreaMarkdown,decorateSectionDocument} from '../lib/ink-experience.js';
import {sectionQueryModel,parseSectionState,sectionQueryHref} from '../lib/section-query.js';
import {createReader,renderResearchMarkdown,renderLegacyDirectory} from '../lib/public-research-reader.js';
import {createQuestionsReader,questionQueryState,renderQuestionWarehouse,emptyPublicQuestions} from '../lib/public-questions.js';
import {sections,entrySectionIds} from '../lib/section-registry.js';
const data=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8')),origin='https://zhongshuderen.pages.dev';
const u=p=>new URL(p,origin),context={next:()=>new Response('not found',{status:404})};

test('six scene actions are distinct, quiet and real links independent of scripting',()=>{
 const actions=['archery','scroll','birds','paths','joint','water'];
 sections.slice(1).forEach((s,i)=>{const h=renderAreaRoute(data,u('/areas/'+s.id+'/'),origin);assert(h.includes('data-landscape-action="'+actions[i]+'"'));assert(!h.includes('theme-hotspot'));assert(!h.includes('>○<'));assert(!h.includes('class="result-item"'));const entries=[...h.matchAll(/class="scene-entry"[^>]+href="([^"]+)"/g)];assert(entries.length>=1&&entries.length<=3);for(const m of entries)assert(m[1].startsWith('/areas/'+s.id+'/search/?q='));});
});
test('out of range pages clamp identically in HTML and Markdown, including canonical and pager',()=>{
 const url=u('/areas/quant-prediction/search/?page=999'),h=renderAreaRoute(data,url,origin),m=renderAreaMarkdown(data,u('/areas/quant-prediction/search/index.md?page=999'),origin),model=sectionQueryModel(data,url,'quant-prediction');
 assert(model.pages>1);assert(model.rows.length>0);assert(h.includes('第 '+model.pages+' / '+model.pages+' 页'));assert(m.includes('第 '+model.pages+' / '+model.pages+' 页'));assert(m.includes(model.rows[0].doc.title));assert(m.includes('page='+model.pages));assert(m.includes('[上一页]'));assert(!m.includes('page=999'));
});
test('contextual detail and Markdown return to the same normalized query, legacy stays global',async()=>{
 const one=data.knowledge.entries.find(e=>e.id.startsWith('tdx-'));
 const fixture={...data,knowledge:{...data.knowledge,entries:Array.from({length:40},(_,i)=>({...one,id:'tdx-return-test-'+i,title:'本地夹具验证 '+i,summary:'本地夹具验证',research_date:'2026-10-01',related:[]}))}};
 const query='/areas/quant-prediction/search/?q=夹具验证&type=tools&date=2026-10-01&page=2',model=sectionQueryModel(fixture,u(query),'quant-prediction');assert.equal(model.state.page,2);
 const reader=createReader({seed:fixture,origin}),article='/library/tdx-return-test-15/?area=quant-prediction&q=夹具验证&type=tools&date=2026-10-01&page=2';
 const html=await(await reader(new Request(origin+article),context)).text();assert(html.includes('data-search-return'));assert(html.includes('type=tools&amp;date=2026-10-01&amp;page=2'));assert(html.includes('返回本次查询'));
 const md=await(await reader(new Request(origin+article.replace('/?','/index.md?')),context)).text();assert(md.includes('返回本次查询'));assert(md.includes('type=tools&date=2026-10-01&page=2'));
 const old=await(await reader(new Request(origin+'/library/tdx-return-test-15/'),context)).text();assert(old.includes('返回搜索结果'));assert(!old.includes('data-search-return'));
});
test('state parser rejects alien areas, malformed dates, arbitrary types and unsafe navigation',()=>{
 assert.equal(parseSectionState(u('/?area=evil'),'evil'),null);const s=parseSectionState(u('/?q=x&type=evil&date=2026-99-99&page=-4&topic=price'),'quant-prediction',['methods']);assert.equal(s.date,'');assert.equal(s.type,'all');assert.equal(s.topic,'all');assert.equal(s.page,1);assert(sectionQueryHref(s).startsWith('/areas/quant-prediction/search/'));
});
test('all three real topics have source-driven Markdown and scoped return; no invented topic',async()=>{
 const reader=createReader({seed:data,origin});for(const t of data.topics){const p='/topics/'+t.id+'/index.md?area='+sections.find(s=>s.topics.includes(t.id)).id+'&page=2';const r=await reader(new Request(origin+p),context);assert.equal(r.status,200);const md=await r.text();assert(md.includes(t.title));assert(md.includes(t.sections[0].paragraphs[0]));assert(md.includes('返回本次查询'));}assert.equal(renderResearchMarkdown(data,u('/topics/not-real/index.md'),origin),null);
 for(const p of ['/research/','/topics/','/explore/'])assert(renderLegacyDirectory(data,u(p),origin).includes('directory-paper'));
});
const qa=i=>({id:'qa-local-'+i,title:'本地分页夹具 '+i,question:'只用于本地测试的分页问题，怎样保留事实和未知？',display_name:'本地测试',submitted_at:'2026-10-13T08:00:00Z',published_at:'2026-10-13T08:10:00Z',status:i%2?'answered':'awaiting_answer',answer:i%2?'仅本地夹具答复，不进入公开网站。':null,answered_at:i%2?'2026-10-13T08:20:00Z':null});
test('question warehouse filters/paginates locally and HTML/Markdown have the same last page',()=>{
 const fixture={schema_version:1,updated_at:'2026-10-13T09:00:00Z',items:Array.from({length:27},(_,i)=>qa(i))},url=u('/ask/search/?q=夹具&status=answered&page=999'),state=questionQueryState(url,fixture);
 assert.equal(state.total,13);assert.equal(state.page,2);assert.equal(state.rows.length,3);const h=renderQuestionWarehouse(fixture,url,origin),md=renderQuestionWarehouse(fixture,url,origin,{markdown:true});assert(h.includes('第 2 / 2 页'));assert(md.includes('第 2 / 2 页'));assert(md.includes('status=answered&page=2'));assert(h.includes('qa-local-9'));assert(!h.includes('qa-local-26/'));assert.equal(emptyPublicQuestions.items.length,0);
});
test('legacy drafts redirect to no-store real form and cannot inject HTML or replacement syntax',async()=>{
 const reader=createQuestionsReader({origin,fetcher:async()=>new Response(JSON.stringify(emptyPublicQuestions))});const draft='$& <script>bad</script> 这是本地草稿';const r=await reader(new Request(origin+'/ask/?question='+encodeURIComponent(draft)),context);assert.equal(r.status,303);assert(r.headers.get('Location').startsWith('/ask/new/?question='));
 const form=await reader(new Request(origin+r.headers.get('Location')),context),html=await form.text();assert.equal(form.headers.get('Cache-Control'),'no-store');assert(html.includes('$&amp; &lt;script&gt;bad&lt;/script&gt;'));assert(!html.includes('<script>bad</script>'));assert(html.includes('name="publication-consent"'));assert(html.includes('name="bot-field"'));assert(html.includes('action="/ask/received/"'));assert.equal(emptyPublicQuestions.items.length,0);
});
test('shared methods and unknowns remain reachable globally instead of filling every area',()=>{const method=data.knowledge.entries.find(e=>e.id==='method-evidence');assert.deepEqual(entrySectionIds(method,data),[]);const unknown=data.knowledge.entries.find(e=>e.id==='archive-ybb55o');assert.deepEqual(entrySectionIds(unknown,data),[]);assert.equal(data.knowledge.entries.length,4947);});
