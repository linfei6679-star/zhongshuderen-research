import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import vm from 'node:vm';
import {createCloudflareWorker,rewritePresentation,cloudflareVisitorScript} from '../cloudflare/worker.js';
import {makeCloudflarePlan,bundleLocalModules,makeZip,checkout,outputDirectory,outputZip} from '../scripts/build-cloudflare.mjs';
import {emptyPublicQuestions} from '../lib/public-questions.js';

const origin='https://zhongshuderen.pages.dev';
const seed=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8'));
const revision=crypto.createHash('sha256').update(JSON.stringify(seed)).digest('hex');
const config={seed,origin,revision,builtAt:'2026-10-13T10:00:00.000Z',notes:JSON.parse(fs.readFileSync(new URL('../content/notes.json',import.meta.url))),questions:JSON.parse(fs.readFileSync(new URL('../content/questions.json',import.meta.url))),publicQuestions:emptyPublicQuestions};
const offline=async()=>{throw Error('offline');};
const app=createCloudflareWorker(config,{fetcher:offline});
const assetRequests=[];
const env={ASSETS:{fetch:async request=>{assetRequests.push(request.url);const p=new URL(request.url).pathname;return new Response(p==='/unknown'?'missing':p,{status:p==='/unknown'?404:200,headers:{'Content-Type':p.endsWith('.json')?'application/json':'text/plain'}});}}};

test('existing homepage, live search query and deep HTML/Markdown survive migration',async()=>{
 const home=await app.fetch(new Request(origin+'/'),env);assert.equal(home.status,200);const html=await home.text();
 assert.match(html,/大师古法手解/);assert.match(html,/道场累计访客统计读取中/);assert.doesNotMatch(html,/旧站最近记录|新站统计待接入/);assert.equal((html.match(/id="visitor-total-summary"/g)||[]).length,1);assert(!html.includes('id="visitor-stats"'));
 const result=await app.fetch(new Request(origin+'/library/?q=000930'),env);const body=await result.text();assert.match(body,/检索：000930/);assert.match(body,/中粮科技/);assert.match(body,/from=000930/);
 const stock=await app.fetch(new Request(origin+'/stocks/000930/'),env);assert.equal(stock.status,200);assert.match(await stock.text(),/中粮科技/);
 const md=await app.fetch(new Request(origin+'/stocks/000930/index.md'),env);assert.match(md.headers.get('Content-Type'),/plain|markdown/);assert.match(await md.text(),/中粮科技/);
 assert.equal(result.headers.get('X-Research-Revision'),revision);
});

test('topic table filters, static 404 and HEAD semantics are preserved',async()=>{
 const board=await app.fetch(new Request(origin+'/library/stock-research-price-mapping/?q=000930&level=all'),env);const body=await board.text();assert.match(body,/中粮科技/);assert.match(body,/value="000930"/);
 const missing=await app.fetch(new Request(origin+'/unknown'),env);assert.equal(missing.status,404);assert.equal(await missing.text(),'missing');
 const head=await app.fetch(new Request(origin+'/library/?q=量化',{method:'HEAD'}),env);assert.equal(head.status,200);assert.equal(await head.text(),'');
});

test('large JSON/index/sitemap use static binding instead of request serialization',async()=>{
 for(const p of ['/research.json','/api/research','/knowledge-index.json','/sitemap.xml','/llms.txt']){const res=await app.fetch(new Request(origin+p),env);assert.equal(await res.text(),p==='/api/research'?'/research.json':p);}
 assert.equal(new URL(assetRequests.at(-5)).pathname,'/research.json');
 const stats=await app.fetch(new Request(origin+'/visitor-stats.json'),env);assert.equal(stats.status,503);assert.equal((await stats.json()).unique_visitors,undefined);
});

test('old-origin rewriting preserves external sources and source JSON',()=>{
 const old='https://zhongshuderen-research.netlify.app';
 const html='<link rel="canonical" href="'+old+'/about/"><a href="'+old+'/stocks/000930/">one</a><a href="'+old+'.evil.test/x">two</a><a href="https://source.test/?next='+old+'/">source</a><meta property="og:url" content="'+old+'/about/">';
 const result=rewritePresentation(html,origin);assert.match(result,new RegExp('canonical" href="'+origin+'/about/'));assert.match(result,/href="\/stocks\/000930\/"/);assert.ok(result.includes(old+'.evil.test'));assert.ok(result.includes('https://source.test/?next='+old+'/'));assert.ok(result.includes('content="'+origin+'/about/'));
 assert.equal(rewritePresentation('[one]('+old+'/x/) [two](https://source.test/?q='+old+'/x/) ',origin,'text/plain'),'[one](/x/) [two](https://source.test/?q='+old+'/x/) ');
 const json=JSON.stringify({url:old+'/x/'});assert.equal(rewritePresentation(json,origin,'application/json'),json);
 const schema='<script type="application/ld+json">'+json+'</script><a href="'+old+'">home</a>';const fixed=rewritePresentation(schema,origin);assert.ok(fixed.includes('"url":"'+origin+'/x/"'));assert.ok(fixed.includes('href="/"'));
});

test('legacy and explicit POST paths enter only the private question handler',async()=>{
 const calls=[];const worker=createCloudflareWorker(config,{fetcher:offline,submit:async(req,binding)=>{calls.push([req.url,binding.QUESTIONS_DB,await req.text()]);return new Response('{"ok":true}',{status:201});}});
 for(const p of ['/api/questions','/','/ask/received/'])assert.equal((await worker.fetch(new Request(origin+p,{method:'POST',body:'private-question'}),{QUESTIONS_DB:'private-test'})).status,201);
 assert.equal(calls.length,3);assert.equal(calls[0][1],'private-test');assert.equal((await worker.fetch(new Request(origin+'/api/questions'),env)).status,405);assert.equal((await worker.fetch(new Request(origin+'/library/',{method:'POST'}),env)).status,405);
 const ask=await worker.fetch(new Request(origin+'/ask/new/'),env);const text=await ask.text();assert.match(text,/data-submit-endpoint="\/api\/questions"/);assert.doesNotMatch(text,/data-netlify="true"/);
});

test('large research refresh reads a bounded header and advertises pending deployment',async()=>{
 let requests=0,cancelled=0,tick=1000000;
 const newer=new Date(Date.parse(seed.checked_at)+86400000).toISOString();
 const worker=createCloudflareWorker(config,{now:()=>tick,fetcher:async url=>{
  requests++;assert.match(url,/public-research-data.json/);
  return new Response(new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode('{"schema_version":1,"checked_at":"'+newer+'","data":"'+'.'.repeat(20000)));},cancel(){cancelled++;}}));
 }});
 await worker.checkForUpdates();await worker.checkForUpdates();assert.equal(requests,1);assert.equal(cancelled,1);assert.equal(worker.status().update_available,true);assert.equal(worker.status().research_checked_at,seed.checked_at);assert.equal(worker.status().mode,'validated_snapshot_deployment');
 tick+=30*60*1000;await worker.checkForUpdates();assert.equal(requests,2);
 const response=await worker.fetch(new Request(origin+'/publication-status.json'),env);assert.equal(response.headers.get('Cache-Control'),'no-store');assert.equal((await response.json()).repository_checked_at,newer);
});

test('small public questions can refresh separately while failed reads keep the seed',async()=>{
 let fetches=0;const updated={schema_version:1,updated_at:'2026-10-13T11:00:00.000Z',items:[{id:'qa-migration',title:'怎样阅读研究',question:'面对研究材料应该先查看哪一部分内容？',display_name:'读者',submitted_at:'2026-10-13T09:00:00Z',published_at:'2026-10-13T10:00:00Z',status:'awaiting_answer',answer:null,answered_at:null}]};
 const worker=createCloudflareWorker({...config,publicQuestions:updated},{fetcher:async()=>{fetches++;return new Response(JSON.stringify(updated),{headers:{'Content-Type':'application/json'}});}});
 const q=await worker.fetch(new Request(origin+'/ask/questions/qa-migration/'),env);assert.match(await q.text(),/怎样阅读研究/);assert.equal(fetches,1);
 const offlineWorker=createCloudflareWorker({...config,publicQuestions:updated},{fetcher:offline});const fallback=await offlineWorker.fetch(new Request(origin+'/questions.json'),env);assert.equal((await fallback.json()).items.length,1);
});

test('new public questions enter their live sitemap without rebuilding the research sitemap',async()=>{
 const latest={schema_version:1,updated_at:'2026-10-13T11:00:00.000Z',items:[{id:'qa-new-after-build',title:'新收到的问题',question:'怎样理解这次新发布的研究材料及其出处？',display_name:'读者',submitted_at:'2026-10-13T09:00:00Z',published_at:'2026-10-13T10:00:00Z',status:'awaiting_answer',answer:null,answered_at:null}]};
 let fetches=0;const worker=createCloudflareWorker({...config,publicQuestions:emptyPublicQuestions},{fetcher:async()=>{fetches++;return new Response(JSON.stringify(latest));}});
 const result=await worker.fetch(new Request(origin+'/ask/sitemap.xml'),env);assert.equal(result.status,200);assert.match(result.headers.get('Content-Type'),/application\/xml/);const xml=await result.text();assert.ok(xml.includes(origin+'/ask/questions/qa-new-after-build/'));assert.match(xml,/<lastmod>2026-10-13T10:00:00Z<\/lastmod>/);assert.equal(fetches,1);
 const head=await worker.fetch(new Request(origin+'/ask/sitemap.xml',{method:'HEAD'}),env);assert.equal(head.status,200);assert.equal(await head.text(),'');assert.equal(fetches,1);
 assert.equal(await(await worker.fetch(new Request(origin+'/sitemap.xml'),env)).text(),'/sitemap.xml');
 const plan=makeCloudflarePlan({origin,builtAt:config.builtAt});const robots=plan.files.get('robots.txt').body.toString();assert.ok(robots.includes('Sitemap: '+origin+'/sitemap.xml\n'));assert.ok(robots.includes('Sitemap: '+origin+'/ask/sitemap.xml\n'));assert.ok(!plan.files.get('sitemap.xml').body.toString().includes('qa-new-after-build'));
});

test('dry-run plans only whitelisted assets and bundles without installing tools',async()=>{
 const before=[fs.existsSync(outputDirectory),fs.existsSync(outputZip)];
 const plan=makeCloudflarePlan({origin,builtAt:config.builtAt});assert.deepEqual([fs.existsSync(outputDirectory),fs.existsSync(outputZip)],before);assert.equal(plan.manifest.revision,revision);assert.ok(plan.files.size<1000);assert.ok(plan.files.has('_worker.js'));assert.ok(plan.files.has('research.json'));assert.ok(![...plan.files].some(([name])=>name.includes('private')||name.startsWith('stocks/')));
 assert.deepEqual(JSON.parse(plan.files.get('research.json').body).knowledge.entries,seed.knowledge.entries);assert.match(plan.files.get('sitemap.xml').body.toString(),/stocks\/000930/);assert.ok(!plan.files.get('sitemap.xml').body.toString().includes('netlify.app'));
 const packed=bundleLocalModules('cloudflare/worker.js');const mod=await import('data:text/javascript;base64,'+Buffer.from(packed.code+'\nexport const createCloudflareWorker='+packed.entryId+'.createCloudflareWorker;').toString('base64'));
 const compiled=mod.createCloudflareWorker(config,{fetcher:offline});assert.equal(await(await compiled.fetch(new Request(origin+'/library/?q=000930'),env)).text(),await(await app.fetch(new Request(origin+'/library/?q=000930'),env)).text());
});

test('restricted bundler fails closed on unsupported imports and cycles; zip is real deflate',()=>{
 const virtual=path.join(checkout,'virtual');assert.throws(()=>bundleLocalModules('entry.js',{root:virtual,readSource:()=>"import x from './x.js';"}),/Unsupported import/);
 assert.throws(()=>bundleLocalModules('entry.js',{root:virtual,readSource:()=>"import {x} from './entry.js';\nexport const x=1;"}),/Circular/);
 const input=new Map([['small.txt',{body:Buffer.from('same content')}]]);const zip=makeZip(input);assert.equal(zip.readUInt32LE(0),0x04034b50);const compressedSize=zip.readUInt32LE(18),nameSize=zip.readUInt16LE(26);assert.equal(zlib.inflateRawSync(zip.subarray(30+nameSize,30+nameSize+compressedSize)).toString(),'same content');assert.equal(zip.readUInt32LE(zip.length-22),0x06054b50);
});

test('only delivered 200 HTML GETs schedule counting; counter failure leaves content intact',async()=>{
 const counted=[],pending=[];const ctx={waitUntil:p=>pending.push(p)};
 const worker=createCloudflareWorker(config,{fetcher:offline,recordVisit:async(req,_env,_ctx,response)=>{counted.push([new URL(req.url).pathname,response.status]);throw Error('database unavailable');}});
 const first=await worker.fetch(new Request(origin+'/'),env,ctx);assert.equal(first.status,200);assert.match(await first.text(),/种树的人/);
 await worker.fetch(new Request(origin+'/stocks/000930/'),env,ctx);
 await worker.fetch(new Request(origin+'/stocks/000930/',{method:'HEAD'}),env,ctx);
 await worker.fetch(new Request(origin+'/stocks/000930/index.md'),env,ctx);
 await worker.fetch(new Request(origin+'/research.json'),env,ctx);
 await worker.fetch(new Request(origin+'/unknown'),env,ctx);
 await Promise.all(pending);assert.deepEqual(counted,[['/',200],['/stocks/000930/',200]]);
});

test('stats endpoint uses current-site aggregate and does not substitute old values on errors',async()=>{
 const sample={schema_version:1,observed_at:new Date().toISOString(),window_hours:24,unique_visitors:7,pageviews:12,source:'Cloudflare D1 Website Analytics',method:'unique_ip'};
 const worker=createCloudflareWorker(config,{fetcher:offline,readStats:async()=>new Response(JSON.stringify(sample),{headers:{'Content-Type':'application/json'}})});
 assert.deepEqual(await(await worker.fetch(new Request(origin+'/visitor-stats.json'),env)).json(),sample);
 const failed=createCloudflareWorker(config,{fetcher:offline,readStats:async()=>{throw Error('offline');}});const response=await failed.fetch(new Request(origin+'/visitor-stats.json'),env);assert.equal(response.status,503);assert.equal((await response.json()).unique_visitors,undefined);
});

test('footer refresh is idempotent, rejects legacy source, and never invents zero',async()=>{
 const original='<small id="visitor-stats">old</small>';const once=rewritePresentation(original,origin),twice=rewritePresentation(once,origin);assert.equal(once,twice);
 const code=cloudflareVisitorScript.match(/^<script[^>]*>([\s\S]*)<\/script>$/)[1];
 async function execute(value,reject=false){const node={textContent:'新站访客统计读取中……',dataset:{}};vm.runInNewContext(code,{document:{getElementById:()=>node},fetch:async()=>{if(reject)throw Error('offline');return {ok:true,json:async()=>value};},AbortSignal,Intl,Date});await new Promise(resolve=>setImmediate(resolve));return node;}
 const sample={schema_version:1,observed_at:new Date().toISOString(),window_hours:24,unique_visitors:7,pageviews:12,source:'Cloudflare D1 Website Analytics',method:'unique_ip'};
 assert.match((await execute(sample)).textContent,/访客：7/);assert.match((await execute({...sample,source:'Netlify Web Analytics'})).textContent,/暂未读取/);assert.match((await execute(null,true)).textContent,/暂未读取/);assert.doesNotMatch((await execute(null,true)).textContent,/：0/);
});

test('receipt page only confirms an existing private submission id without exposing its contents',async()=>{
 const receipt='qs_12345678-1234-1234-1234-123456789abc';const queries=[];
 const db={prepare:sql=>({bind:value=>({first:async()=>{queries.push([sql,value]);return value===receipt?{id:receipt}:null;}})})};
 const context={...env,QUESTIONS_DB:db};
 for(const suffix of ['', '?receipt=anything','?receipt=qs_00000000-0000-0000-0000-000000000000']){
  const result=await app.fetch(new Request(origin+'/ask/received/'+suffix),context);assert.equal(result.status,303);assert.equal(result.headers.get('Location'),'/ask/?unconfirmed=1');assert.doesNotMatch(await result.text(),/已收到/);
 }
 const result=await app.fetch(new Request(origin+'/ask/received/?receipt='+receipt),context);assert.equal(result.status,200);assert.equal(result.headers.get('Cache-Control'),'no-store');assert.equal(result.headers.get('X-Robots-Tag'),'noindex');assert.match(await result.text(),/已收到/);
 const head=await app.fetch(new Request(origin+'/ask/received/?receipt='+receipt,{method:'HEAD'}),context);assert.equal(head.status,200);assert.equal(await head.text(),'');
 assert.ok(queries.every(([sql])=>sql==='SELECT id FROM question_submissions WHERE id=? LIMIT 1'));
 const failed=await app.fetch(new Request(origin+'/ask/received/?receipt='+receipt),{...env,QUESTIONS_DB:{prepare(){throw Error('offline');}}});assert.equal(failed.status,303);
});
