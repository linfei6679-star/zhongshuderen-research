import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyPublicQuestions,publicQuestionsDataUrl,validatePublicQuestions,renderPublicQuestions,renderPublicQuestion,createQuestionsReader} from '../lib/public-questions.js';

// Entirely fictional fixtures: tests never write these questions into the public library.
const origin='https://zhongshuderen-research.netlify.app';
const fixture=(status='awaiting_answer')=>({id:'qa-fictional-test',title:'测试数据：如何整理一个问题？',question:'这是虚构测试数据，仅用来检查公开提问功能。\n\n怎样区分事实与推测？',display_name:'测试读者',submitted_at:'2026-10-13T08:00:00.000Z',published_at:'2026-10-13T08:10:00.000Z',status,answer:status==='answered'?'这是虚构测试答复。先列依据，再保留未知。':null,answered_at:status==='answered'?'2026-10-13T08:20:00.000Z':null});
const snapshot=(status='awaiting_answer')=>({schema_version:1,updated_at:'2026-10-13T08:30:00.000Z',items:[fixture(status)]});
const context={next:()=>new Response('passthrough',{status:418})};
const request=(path='/questions.json',init)=>new Request(origin+path,init);

test('the real empty seed has no invented questions; valid waiting and answered fixtures pass',()=>{
 assert.equal(validatePublicQuestions(emptyPublicQuestions),emptyPublicQuestions);assert.equal(emptyPublicQuestions.items.length,0);
 assert(validatePublicQuestions(snapshot()));assert(validatePublicQuestions(snapshot('answered')));
 const html=renderPublicQuestions(emptyPublicQuestions,origin);assert.match(html,/id="public-answers"/);assert.match(html,/这里还没有公开问答/);assert.doesNotMatch(html,/尚无人提问|qa-fictional-test/);
});
test('unknown private fields, contacts, paths and credentials cannot enter the public snapshot',()=>{
 for(const field of ['contact','email','微信','phone','provider_submission_id','internal_path']){
  const data=snapshot();data.items[0][field]='private';assert.throws(()=>validatePublicQuestions(data),field);
 }
 assert.throws(()=>validatePublicQuestions({...snapshot(),raw_submissions:[]}));
 for(const text of ['测试：13800000000','测试：+86 138-0000-0000','测试：qa@example.invalid','测试：微信号：test_contact','测试：wechat ID: example_test','测试：sk-proj-xxxxxxxxxxxxxxxxxxxxxxxx','测试：ghp_XXXXXXXXXXXXXXXXXXXXXXXX','测试：E:\\CHATGPT\\private','测试：/home/fictional/private','测试：\\\\server\\private','测试：１３８００００００００']){
  const data=snapshot();data.items[0].question=text;assert.throws(()=>validatePublicQuestions(data),text);
 }
 const answer=snapshot('answered');answer.items[0].answer='测试：answer@example.invalid';assert.throws(()=>validatePublicQuestions(answer));
 const identity=snapshot();identity.items[0].id='qa-13800000000';assert.throws(()=>validatePublicQuestions(identity));
 const publicLink=snapshot();publicLink.items[0].question='测试公开信源：https://example.invalid/home/research';assert(validatePublicQuestions(publicLink));
});
test('identities, required fields, real calendar dates and answer state are enforced',()=>{
 for(const change of [{id:'../qa-test'},{id:'qa-test/unsafe'},{title:'x'.repeat(81)},{question:'x'.repeat(2001)},{display_name:'x'.repeat(41)},{submitted_at:'2026-02-30T10:00:00Z'},{published_at:'2026-10-13'},{status:'draft'},{answer:'不能在待答状态塞答案'},{answered_at:'2026-10-13T08:20:00Z'}]){
  const data=snapshot();Object.assign(data.items[0],change);assert.throws(()=>validatePublicQuestions(data));
 }
 const missing=snapshot();delete missing.items[0].answer;assert.throws(()=>validatePublicQuestions(missing));
 const answered=snapshot('answered');answered.items[0].answer=null;assert.throws(()=>validatePublicQuestions(answered));
 const duplicate=snapshot();duplicate.items.push({...duplicate.items[0]});assert.throws(()=>validatePublicQuestions(duplicate));
 const huge=snapshot();huge.items=Array.from({length:1001},(_,i)=>({...fixture(),id:'qa-test-'+i}));assert.throws(()=>validatePublicQuestions(huge));
 const bytes=snapshot();bytes.items=Array.from({length:200},(_,i)=>({...fixture(),id:'qa-test-'+i,question:'测'.repeat(2000)}));assert.throws(()=>validatePublicQuestions(bytes),/one MiB/);
});
test('HTML escapes visitor text and distinguishes human-confirmed answers from pending questions',()=>{
 const item=fixture();item.title='测试：<script>alert(1)</script>';item.question='测试：<img src=x onerror=alert(1)>';item.display_name='<b>测试化名</b>';
 const html=renderPublicQuestion(item,origin);assert.doesNotMatch(html,/<script>alert\(1\)|<img src=x|<b>测试化名/);assert.match(html,/&lt;script&gt;/);assert.match(html,/&lt;img/);assert.match(html,/尚未确认答复/);assert.doesNotMatch(html,/acceptedAnswer/);
 const answered=renderPublicQuestion(fixture('answered'),origin);assert.match(answered,/答复人：种树的人/);assert.match(answered,/acceptedAnswer/);assert.match(answered,/index\.md/);assert.match(answered,/2026-10-13T08:20:00.000Z/);
 const list=renderPublicQuestions(snapshot('answered'),origin);assert.match(list,/种树的人已答复/);assert.match(list,/href="\/ask\/questions\/qa-fictional-test\/"/);
});
test('five-minute cache coalesces concurrent reads and publishes subsequent validated updates',async()=>{
 let tick=0,calls=0,remote=snapshot();
 const reader=createQuestionsReader({origin,now:()=>tick,fetcher:async url=>{calls++;assert(url.startsWith(publicQuestionsDataUrl+'?window='));await Promise.resolve();return new Response(JSON.stringify(remote));}});
 const responses=await Promise.all([reader(request(),context),reader(request(),context),reader(request(),context)]);
 assert.equal(calls,1);assert.equal((await responses[0].json()).items[0].status,'awaiting_answer');
 remote=snapshot('answered');remote.updated_at='2026-10-13T08:40:00.000Z';tick=299999;
 assert.equal((await(await reader(request(),context)).json()).items[0].status,'awaiting_answer');assert.equal(calls,1);
 tick=300000;assert.equal((await(await reader(request(),context)).json()).items[0].status,'answered');assert.equal(calls,2);
});
test('network errors, invalid private data, oversized data and stale snapshots retain the prior real value and date',async()=>{
 let tick=0,mode='valid';const good=snapshot('answered');
 const reader=createQuestionsReader({origin,now:()=>tick,fetcher:async()=>{
  if(mode==='error')throw Error('fixture network failure');
  if(mode==='private')return new Response(JSON.stringify({...good,contact:'private'}));
  if(mode==='large')return new Response(' '.repeat(1024*1024+1));
  if(mode==='stale')return new Response(JSON.stringify({...good,updated_at:'2026-10-13T08:00:00.000Z',items:[]}));
  return new Response(JSON.stringify(good));
 }});
 assert.deepEqual(await(await reader(request(),context)).json(),good);
 for(const failure of ['error','private','large','stale']){mode=failure;tick+=300000;assert.deepEqual(await(await reader(request(),context)).json(),good,failure);}
 const initialFail=createQuestionsReader({origin,fetcher:async()=>{throw Error('fixture initial failure');}});
 assert.deepEqual(await(await initialFail(request(),context)).json(),emptyPublicQuestions);
});
test('POST and unrelated paths bypass the reader without fetching or echoing raw submissions',async()=>{
 let calls=0;const reader=createQuestionsReader({origin,fetcher:async()=>{calls++;return new Response('{}');}});
 const submitted=await reader(request('/ask/received/',{method:'POST',body:'reply-contact=private-fixture'}),context);
 assert.equal(submitted.status,418);assert.equal(await submitted.text(),'passthrough');
 assert.equal((await reader(request('/library/'),context)).status,418);assert.equal(calls,0);
 assert.throws(()=>createQuestionsReader({dataUrl:'https://example.invalid/private'}));
});
test('public routes return safe JSON, HTML, Markdown and bodyless HEAD; unknown IDs return 404',async()=>{
 const reader=createQuestionsReader({origin,seed:snapshot('answered'),fetcher:async()=>{throw Error('fixture offline');}});
 const html=await reader(request('/ask/questions/qa-fictional-test/'),context);assert.equal(html.status,200);assert.match(html.headers.get('Content-Type'),/text\/html/);assert.match(await html.text(),/虚构测试答复/);
 const markdown=await reader(request('/ask/questions/qa-fictional-test/index.md'),context);assert.equal(markdown.status,200);assert.match(markdown.headers.get('Content-Type'),/text\/plain/);assert.match(await markdown.text(),/## 种树的人答/);
 const json=await reader(request(),context);assert.match(json.headers.get('Cache-Control'),/max-age=60, s-maxage=300/);assert.equal(json.headers.get('X-Content-Type-Options'),'nosniff');
 const head=await reader(request('/ask/questions/qa-fictional-test/',{method:'HEAD'}),context);assert.equal(head.status,200);assert.equal(await head.text(),'');
 const missing=await reader(request('/ask/questions/qa-does-not-exist/'),context);assert.equal(missing.status,404);assert.match(await missing.text(),/noindex,follow/);
 const ask=await reader(request('/ask/'),context);const askHtml=await ask.text();assert.match(askHtml,/href="\/ask\/new\/"/);assert.doesNotMatch(askHtml,/id="master-question-form"/);const search=await reader(request('/ask/search/'),context);assert.match(await search.text(),/qa-fictional-test/);
 assert.equal((await reader(request('/ask/received/'),context)).status,200);
});
