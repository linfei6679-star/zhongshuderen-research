// Shared deterministic geometry: no DOM, clocks, research reads or invented fish.
export const clamp=t=>Math.max(0,Math.min(1,t));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const ease=t=>{t=clamp(t);return t*t*(3-2*t);};
const quad=(a,b,c,t)=>[(1-t)**2*a[0]+2*(1-t)*t*b[0]+t*t*c[0],(1-t)**2*a[1]+2*(1-t)*t*b[1]+t*t*c[1]];
export function characterPhase(id,elapsed,fishCount=0){
 if(!Number.isFinite(elapsed)||elapsed<0)throw Error('Invalid character clock');
 if(id==='archer'){const p=elapsed%12000/12000;return {frame:p<.28?0:p<.43?1:p<.72?2:0,lift:0,progress:p,arrowVisible:p>=.43&&p<.58,arrowProgress:clamp((p-.43)/.15),impact:p>=.58&&p<.66};}
 const cycles={craft:12000,horse:15000,observer:14000,traveler:16000,thinker:18000,sage:17000};
 if(Object.hasOwn(cycles,id)){const p=elapsed%cycles[id]/cycles[id];return {frame:p<.30?0:p<.46?1:p<.64?2:p<.72?1:0,lift:0,progress:p,path:id==='traveler'?(p>=.30&&p<.46?0:p>=.46&&p<.64?1:-1):-1};}
 if(id!=='fisher')throw Error('Unknown character scene');
 if(!fishCount){const p=elapsed%12000/12000;return {frame:p>=.30&&p<.40?1:0,lift:0};}
 const p=elapsed%11000/11000;return {frame:p<.25?0:p<.62?1:p<.94?2:0,lift:p<.25?0:p<.62?ease((p-.25)/.37):p<.9?1:1-ease((p-.9)/.1),progress:p,selected:Math.floor(elapsed/11000)%fishCount};
}
export function fishPose(start,p,{stopped=false}={}){
 let point=[...start],scale=1,opacity=1;
 if(!stopped&&p>.25){
  if(p<.60){const t=ease((p-.25)/.35);point=quad(start,[1160,470],[1245,455],t);scale=lerp(1,.55,t);}
  else if(p<.78){const t=ease((p-.60)/.18);point=quad([1245,455],[1460,500],[1635,440],t);scale=lerp(.55,.20,t);}
  else if(p<.88){const t=ease((p-.78)/.10);point=quad([1635,440],[1650,375],[1630,310],t);scale=.20;}
  else if(p<.94){const t=ease((p-.88)/.06);point=quad([1630,310],[1615,295],[1557.5,342],t);scale=.20;}
  else{const t=ease((p-.94)/.06);point=[1557.5,lerp(342,392,t)];scale=lerp(.20,.12,t);opacity=p>.98?1-ease((p-.98)/.02):1;}
 }
 return {x:point[0],y:point[1],scale,opacity};
}
export function rodPose(config,frame,lift){
 const [gx,gy]=config.frameGrips[frame]||config.grip,tx=config.rodTip[0]+gx-config.grip[0],ty=config.rodTip[1]+gy-config.grip[1],angle=lift*config.rodLiftDegrees*Math.PI/180;
 const tip=[gx+(tx-gx)*Math.cos(angle)-(ty-gy)*Math.sin(angle),gy+(tx-gx)*Math.sin(angle)+(ty-gy)*Math.cos(angle)];
 return {grip:[gx,gy],tip};
}
export function createImageLoader(ImageType=Image){
 const cache=new Map();
 const load=url=>{if(cache.has(url))return cache.get(url);const pending=new Promise((resolve,reject)=>{const image=new ImageType();image.onload=()=>image.naturalWidth?resolve(image):reject(Error('Empty image'));image.onerror=()=>reject(Error('Image unavailable'));image.src=url;}).catch(error=>{cache.delete(url);throw error;});cache.set(url,pending);return pending;};
 return {load,invalidate:url=>cache.delete(url)};
}
