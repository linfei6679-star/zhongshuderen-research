import {characterPhase,fishPose,rodPose,createImageLoader,ease,lerp} from './character-motion.js?v=20261023a';
const images=createImageLoader();
for(const layer of document.querySelectorAll('[data-character]')){
 const stage=layer.closest('.ink-scene'),site=document.getElementById('site'),base=stage?.querySelector('.ink-backdrop'),patch=layer.querySelector('.character-clean'),actor=layer.querySelector('.character-actor'),greeting=layer.querySelector('.character-greeting'),atlasProbe=layer.querySelector('.character-atlas-probe');
 if(!stage||!base||!patch||!actor||!greeting||!atlasProbe)continue;
 let config;try{config=JSON.parse(layer.querySelector('.character-config').textContent);}catch{continue;}
 const greetings=[greeting,...stage.querySelectorAll('[data-character-control="'+config.id+'"] .character-greeting')];
 stage.dataset.characterPolicy='loading';
 const reduce=matchMedia('(prefers-reduced-motion: reduce)'),mobile=matchMedia('(max-width:760px)'),coarse=matchMedia('(pointer:coarse)'),raw=stage.querySelector('#fish-scene-data');
 let fish=[];try{fish=raw?JSON.parse(raw.textContent):[];}catch{}
 const links=[...stage.querySelectorAll('[data-fish]')];
 let ready=false,loading=false,generation=0,visible=true,elapsed=0,last=0,raf=0,replyTimer=0,hovered=false,focused=false,clicked=false,fishHovered=false,fishFocused=false;
 const autoAllowed=()=>ready&&visible&&!document.hidden&&!reduce.matches&&!mobile.matches&&!coarse.matches&&!site?.classList.contains('reduced');
 const position=(node,r)=>{for(const key of ['left','top','width','height'])node.style[key]=r[key]/(key==='top'||key==='height'?941:1672)*100+'%';};
 function sprite(frame){const offset=config.registration[frame]||{x:0,y:0};position(actor,{...config.actor,left:config.actor.left+offset.x,top:config.actor.top+offset.y});actor.style.backgroundPosition=[[0,0],[100,0],[0,100],[100,100]][frame].map(n=>n+'%').join(' ');layer.dataset.characterFrame=String(frame);}
 function draw(){
  if(!ready)return;
  const automatic=autoAllowed()&&!fishHovered&&!fishFocused,responding=visible&&!document.hidden&&(hovered||focused||clicked),phase=characterPhase(config.id,elapsed,fish.length),frame=responding?3:autoAllowed()&&!fishFocused?phase.frame:0;
  sprite(frame);layer.dataset.characterState=responding?'respond':automatic&&!fishHovered&&!fishFocused?'working':'idle';for(const button of greetings)button.setAttribute('aria-pressed',String(responding));stage.dataset.characterPolicy=layer.dataset.characterState==='working'?'running':layer.dataset.characterState;
  layer.dataset.characterElapsed=String(Math.round(elapsed));
  if(config.id==='archer'){const flying=automatic&&!responding&&phase.arrowVisible,impact=automatic&&!responding&&phase.impact,x=lerp(1422,1566,phase.arrowProgress),y=lerp(481,486,phase.arrowProgress);const arrow=layer.querySelector('[data-character-arrow]');arrow.setAttribute('d',`M${x-30} ${y}L${x} ${y}m-7-4 7 4-7 4`);arrow.style.opacity=flying?'1':'0';layer.querySelector('[data-character-impact]').style.opacity=impact?'.4':'0';}
  if(config.id==='traveler')stage.querySelectorAll('.scene-paths path').forEach((node,i)=>{const active=automatic&&!responding&&phase.path===i;node.style.strokeDashoffset=active?'0':'1';node.style.setProperty('opacity',active?'.45':'0','important');});
  if(config.id!=='fisher')return;
  const stable=!automatic||fishFocused||responding;
  const {grip,tip}=rodPose(config,frame,stable?0:phase.lift);let bindings='';
  layer.querySelector('[data-character-rod]').setAttribute('d',`M${grip[0]+14} ${grip[1]+4}Q${(grip[0]+tip[0])/2} ${(grip[1]+tip[1])/2-5} ${tip[0]} ${tip[1]}`);
  for(let i=1;i<=6;i++){const t=i/7;bindings+=`M${lerp(grip[0],tip[0],t)-1} ${lerp(grip[1],tip[1],t)-3}l-2 6`;}
  layer.querySelector('[data-character-bindings]').setAttribute('d',bindings);
  let mouth=null;
  for(let i=0;i<links.length;i++){
   const selected=i===phase.selected,pose=fishPose(fish[i].start,selected?phase.progress:0,{stopped:stable||!selected});
   links[i].style.left=pose.x/1672*100+'%';links[i].style.top=pose.y/941*100+'%';links[i].style.transform=`translate(-50%,-50%) scale(${pose.scale})`;links[i].style.opacity=String(pose.opacity);
   if(selected){const width=links[i].offsetWidth/(stage.clientWidth||1)*1672;mouth=[pose.x-width*.44*pose.scale,pose.y+2];}
  }
  const lineActive=!!mouth&&!stable&&phase.progress<.94;layer.dataset.characterLineActive=String(lineActive);
  if(mouth){let [hx,hy]=mouth;if(phase.progress<.22){const t=ease(phase.progress/.22);hx=lerp(tip[0],hx,t);hy=lerp(tip[1]+23,hy,t);}layer.querySelector('[data-character-line]').setAttribute('d',`M${tip[0]} ${tip[1]}Q${(tip[0]+hx)/2} ${(tip[1]+hy)/2+10} ${hx} ${hy}`);layer.querySelector('[data-character-hook]').setAttribute('d',`M${hx} ${hy-9}q-8 16 2 13q8-1 4-9`);}
 }
 function cancelFrame(){if(raf)cancelAnimationFrame(raf);raf=0;last=0;}
 function schedule(){cancelFrame();draw();if(autoAllowed()&&!hovered&&!focused&&!clicked&&!fishHovered&&!fishFocused)raf=requestAnimationFrame(tick);}
 function tick(now){raf=0;if(!autoAllowed()||hovered||focused||clicked||fishHovered||fishFocused){schedule();return;}elapsed+=last?Math.min(70,now-last):0;last=now;draw();raf=requestAnimationFrame(tick);}
 function resetSceneTools(){
  for(const node of stage.querySelectorAll('.scene-paths path')){node.style.setProperty('opacity','0','important');node.style.strokeDashoffset='1';}
  for(const node of layer.querySelectorAll('[data-character-arrow],[data-character-impact]'))node.style.opacity='0';
 }
 function stableReset(){cancelFrame();elapsed=0;clicked=false;clearTimeout(replyTimer);resetSceneTools();draw();}
 function fallback(){generation++;ready=false;loading=false;hovered=false;focused=false;clicked=false;cancelFrame();clearTimeout(replyTimer);layer.removeAttribute('data-character-ready');layer.removeAttribute('data-character-line-active');layer.dataset.characterState='fallback';resetSceneTools();stage.dataset.characterPolicy='fallback';for(const button of greetings)button.hidden=true;images.invalidate(base.currentSrc||base.src);images.invalidate(config.clean);images.invalidate(config.atlas);for(let i=0;i<links.length;i++){links[i].style.left=fish[i].start[0]/1672*100+'%';links[i].style.top=fish[i].start[1]/941*100+'%';links[i].style.transform='translate(-50%,-50%)';links[i].style.opacity='1';}}
 async function activate(){if(ready||loading||document.hidden)return;loading=true;const token=++generation;
  try{const loaded=await Promise.all([images.load(base.currentSrc||base.src),images.load(config.clean),images.load(config.atlas)]);await Promise.all(loaded.map(img=>img.decode?img.decode():Promise.resolve()));if(token!==generation)return;patch.src=config.clean;atlasProbe.src=config.atlas;await Promise.all([patch.decode?.(),atlasProbe.decode?.()]);if(token!==generation)return;position(actor,config.actor);position(greeting,config.hit);patch.style.clipPath=config.cleanClip;actor.style.backgroundImage=`url("${config.atlas}")`;ready=true;loading=false;elapsed=0;sprite(0);layer.dataset.characterReady='true';for(const button of greetings)button.hidden=false;schedule();}catch{if(token===generation)fallback();}
 }
 for(const greeting of greetings){greeting.addEventListener('pointerenter',event=>{if(event.pointerType!=='touch'){hovered=true;schedule();}});greeting.addEventListener('pointerleave',()=>{hovered=false;schedule();});
 greeting.addEventListener('focus',()=>{focused=greeting.matches(':focus-visible');schedule();});greeting.addEventListener('blur',()=>{focused=false;schedule();});
 greeting.addEventListener('click',()=>{clicked=true;clearTimeout(replyTimer);const reply=stage.querySelector('.character-reply');if(reply)reply.textContent=config.label+'回应了';schedule();replyTimer=setTimeout(()=>{clicked=false;if(reply)reply.textContent='';schedule();},1800);});}
 const navigationLinks=[...new Set([...links,...stage.querySelectorAll('.scene-object-hit,.scene-entry,.ask-entry-links a')])];
 for(const link of navigationLinks){link.addEventListener('pointerenter',()=>{fishHovered=true;schedule();});link.addEventListener('pointerleave',()=>{fishHovered=false;schedule();});link.addEventListener('focus',()=>{fishFocused=true;schedule();});link.addEventListener('blur',()=>{fishFocused=false;schedule();});}
 const policy=()=>{if(!autoAllowed()){cancelFrame();elapsed=0;}schedule();};
 for(const mq of [reduce,mobile,coarse])mq.addEventListener('change',policy);
 if(site)new MutationObserver(policy).observe(site,{attributes:true,attributeFilter:['class']});
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(!visible){hovered=false;focused=false;stableReset();}else if(!ready)activate();schedule();},{threshold:.1}).observe(layer);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){hovered=false;focused=false;stableReset();}else if(!ready)activate();schedule();});
 base.addEventListener('error',fallback);patch.addEventListener('error',fallback);atlasProbe.addEventListener('error',fallback);
 window.addEventListener('online',()=>{if(!ready)activate();});window.addEventListener('focus',()=>{if(!ready)activate();});
 activate();
}
