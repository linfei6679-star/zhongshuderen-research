import {sections,sectionPath} from '../lib/section-registry.js';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {validatePublicSnapshot} from '../lib/public-research-reader.js';
import {validatePublicQuestions,emptyPublicQuestions} from '../lib/public-questions.js';
import {knowledgeIndex,knowledgePaths,llmsIndex} from '../lib/knowledge-library.js';
import {topics} from '../lib/discovery.js';
import {visualAssets,lieziCharacterAssets} from '../lib/visual-library.js';
import {rewritePresentation} from '../cloudflare/worker.js';

export const checkout=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const outputDirectory=path.resolve(checkout,'../../outputs/cloudflare-site');
export const outputZip=path.resolve(checkout,'../../outputs/cloudflare-site.zip');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const readJson=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const inside=(root,file)=>file.startsWith(root+path.sep);

// Deliberately narrow compiler for this repository's small, dependency-free ESM
// graph. No eval, third-party install, runtime module loader or private files.
export function bundleLocalModules(entry,{readSource=file=>fs.readFileSync(file,'utf8'),root=checkout}={}){
 const modules=new Map(),visiting=new Set(),chunks=[];
 function compile(file){
  file=path.resolve(file);if(!inside(root,file))throw Error('Module escaped checkout');
  if(modules.has(file))return modules.get(file);if(visiting.has(file))throw Error('Circular module imports are unsupported');
  visiting.add(file);let source=readSource(file),imports=[];
  source=source.replace(/^import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"];?\s*$/gm,(_all,names,relative)=>{
   if(!relative.startsWith('.')||!relative.endsWith('.js'))throw Error('Only local JS imports are supported');
   const bindings=names.split(',').map(s=>s.trim()).filter(Boolean);
   if(bindings.some(s=>!/^[$\w]+(?:\s+as\s+[$\w]+)?$/.test(s)))throw Error('Unsupported import binding');
   const dependency=compile(path.resolve(path.dirname(file),relative));
   imports.push('const {'+bindings.map(s=>s.replace(/\s+as\s+/,':')).join(',')+'}='+dependency+';');return '';
  });
  if(/^\s*import\b/m.test(source)||/\bimport\s*\(/.test(source))throw Error('Unsupported import form');
  const exports=[];
  source=source.replace(/^export\s+(async\s+function|const|let|function)\s+([$\w]+)/gm,(_all,type,name)=>{exports.push(name);return type+' '+name;});
  if(/^\s*export\b/m.test(source))throw Error('Unsupported export form');
  const id='module'+modules.size;modules.set(file,id);visiting.delete(file);
  chunks.push('const '+id+'=(()=>{\n'+imports.join('\n')+'\n'+source+'\nreturn {'+exports.join(',')+'};\n})();');return id;
 }
 const entryId=compile(path.resolve(root,entry));
 return {code:chunks.join('\n'),entryId,modules:[...modules.keys()].map(file=>path.relative(root,file).replaceAll('\\','/'))};
}

function assertSafeSource(file){
 if(!inside(checkout,file))throw Error('Asset escaped checkout');
 const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink())throw Error('Asset must be a regular source file');
 return fs.readFileSync(file);
}
function dataForRelease(){
 const seed=validatePublicSnapshot(readJson(path.resolve(checkout,'../../outputs/public-research-data.json')));
 const qfile=path.resolve(checkout,'../../outputs/public-questions.json');
 const publicQuestions=fs.existsSync(qfile)?validatePublicQuestions(readJson(qfile)):emptyPublicQuestions;
 return {seed,publicQuestions,notes:readJson(path.join(checkout,'content/notes.json')),questions:readJson(path.join(checkout,'content/questions.json'))};
}
export function makeCloudflarePlan({origin,builtAt=new Date().toISOString()}={}){
 if(!/^https:\/\/[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.pages\.dev$/.test(origin||''))throw Error('Provide the verified https://<project>.pages.dev origin');
 const data=dataForRelease(),revision=hash(JSON.stringify(data.seed));
 const compiled=bundleLocalModules('cloudflare/worker.js');
 const config={...data,origin,revision,builtAt};
 const worker=compiled.code+'\nconst application='+compiled.entryId+'.createCloudflareWorker('+JSON.stringify(config).replace(/</g,'\\u003c')+');\nexport default {fetch:(request,env,ctx)=>application.fetch(request,env,ctx)};\n';
 const files=new Map();
 function add(name,bytes,source='generated'){
  if(!/^[a-zA-Z0-9_.\-/]+$/.test(name)||name.includes('..')||name.startsWith('/'))throw Error('Unsafe asset name');
  if(files.has(name))throw Error('Duplicate output asset');
  let body=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes);
  if(name.endsWith('.html')||name.endsWith('.md'))body=Buffer.from(rewritePresentation(body.toString('utf8'),origin,name.endsWith('.html')?'text/html':'text/markdown'));
  if(body.length>25*1024*1024)throw Error('Asset exceeds dashboard limit');
  files.set(name,{body,source});
 }
 add('_worker.js',worker);
 // Dynamic research pages stay in the Worker: do not emit thousands of files.
 const sourceAssets=['character-scenes.css','character-scenes.js','character-motion.js',...lieziCharacterAssets.map(a=>a.src.slice(1)),'warehouse-theme.css','ink-experience.css','ink-experience.js',...sections.map(s=>'visuals/liezi/'+s.asset),'visuals/liezi/08-ask.webp','visuals/liezi/shore-bird.webp','visuals/liezi/home-tree.webp','visuals/liezi/loan-fish.webp','visuals/liezi/loan-basket.webp','mascot.png','site-ui.css','site-ui.js','stock-board.js','ask-master.css','ask-master.js','artifacts/reversible-context-source.zip',...['research-ai.svg','research-company.svg','research-risk.svg','research-thinking.svg'].map(f=>'visuals/'+f),...visualAssets.map(a=>a.src.slice(1)),...['index.html','library.css','library.js','interactions.css','interactions.js','visuals.css'].map(f=>'design-library/'+f)];
 for(const relative of sourceAssets)add(relative,assertSafeSource(path.join(checkout,'public',relative)),'public/'+relative);
 // These small, already-generated ancillary pages have no research-library copy.
 // The runtime applies the current origin and historic visitor label on delivery.
 const shells=['404.html','about/index.html','services/index.html','questions/index.html','questions/index.md','notes/index.html',...data.notes.flatMap(n=>['notes/'+n.id+'/index.html','notes/'+n.id+'/index.md'])];
 for(const relative of shells)add(relative,assertSafeSource(path.join(checkout,'site',relative)),'site/'+relative);
 for(const project of data.seed.projects){
  const md='# '+project.title+'\n\n作者：种树的人\n\n材料更新时间：'+project.source_updated_at+'\n\n'+project.summary+'\n\n## 当前进度\n'+project.progress.map(x=>'- '+x).join('\n')+'\n\n## 成果\n'+project.results.map(x=>'- '+x).join('\n')+'\n\n## '+project.claim_type+'\n'+project.judgment+'\n\n## 下一步\n'+project.next.map(x=>'- '+x).join('\n')+'\n';
  add('research/'+project.id+'/index.md',md);
 }
 const canonicalPaths=[...sections.flatMap(s=>[sectionPath(s.id),sectionPath(s.id)+'search/']),'/','/ask/','/ask/new/','/ask/search/','/about/','/services/','/questions/','/notes/','/research/','/topics/','/explore/',...topics.map(t=>'/explore/'+t.id+'/'),...data.seed.projects.map(p=>'/research/'+p.id+'/'),...(data.seed.topics||[]).map(t=>'/topics/'+t.id+'/'),...knowledgePaths(data.seed.knowledge),...data.notes.map(n=>'/notes/'+n.id+'/'),...data.publicQuestions.items.map(q=>'/ask/questions/'+q.id+'/')];
 add('sitemap.xml','<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+[...new Set(canonicalPaths)].map(p=>'<url><loc>'+origin+p+'</loc></url>').join('')+'</urlset>');
 add('knowledge-index.json',JSON.stringify(knowledgeIndex(data.seed.knowledge,origin,data.seed.checked_at)));
 add('research.json',JSON.stringify(data.seed));
 add('llms.txt',llmsIndex(data.seed.knowledge,origin));
 add('robots.txt','User-agent: *\nAllow: /\n\nSitemap: '+origin+'/sitemap.xml\nSitemap: '+origin+'/ask/sitemap.xml\n');
 const indexnow=readJson(path.join(checkout,'site-config.json')).indexnow?.key;
 if(indexnow&&/^[a-f0-9]{32}$/.test(indexnow))add(indexnow+'.txt',assertSafeSource(path.join(checkout,'public',indexnow+'.txt')),'public/'+indexnow+'.txt');
 // CSS/images bypass Functions; all HTML gets the tested renderer/404 behavior.
 add('_routes.json',JSON.stringify({version:1,include:['/*'],exclude:['/visuals/*','/mascot.png','/artifacts/*',...sourceAssets.filter(name=>name.endsWith('.css')||name.endsWith('.js')).map(name=>'/'+name)]}));
 if(files.size>1000)throw Error('Dashboard upload file limit exceeded');
 const manifest={schema_version:1,kind:'cloudflare-dashboard-site',origin,built_at:builtAt,revision,entries:data.seed.knowledge.entries.length,projects:data.seed.projects.length,research_checked_at:data.seed.checked_at,research_update_mode:'validated_snapshot_deployment',question_update_mode:'github_refresh_with_validated_seed',update_status_path:'/publication-status.json',modules:compiled.modules,files:[...files].map(([name,item])=>({name,bytes:item.body.length,sha256:hash(item.body),source:item.source})),total_bytes:[...files.values()].reduce((n,item)=>n+item.body.length,0)};
 return {files,manifest};
}

const crcTable=Array.from({length:256},(_,n)=>{for(let j=0;j<8;j++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(buffer){let crc=0xffffffff;for(const b of buffer)crc=crcTable[(crc^b)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
// Standard ZIP using only Node's built-in deflate; no tool install or credentials.
export function makeZip(files){
 const parts=[],directory=[];let offset=0;
 for(const [name,{body}] of files){
  const encoded=Buffer.from(name),compressed=zlib.deflateRawSync(body,{level:9}),crc=crc32(body),local=Buffer.alloc(30),central=Buffer.alloc(46);
  local.writeUInt32LE(0x04034b50,0);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(body.length,22);local.writeUInt16LE(encoded.length,26);
  central.writeUInt32LE(0x02014b50,0);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x800,8);central.writeUInt16LE(8,10);central.writeUInt16LE(33,14);central.writeUInt32LE(crc,16);central.writeUInt32LE(compressed.length,20);central.writeUInt32LE(body.length,24);central.writeUInt16LE(encoded.length,28);central.writeUInt32LE(offset,42);
  parts.push(local,encoded,compressed);directory.push(central,encoded);offset+=local.length+encoded.length+compressed.length;
 }
 const central=Buffer.concat(directory),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.size,8);end.writeUInt16LE(files.size,10);end.writeUInt32LE(central.length,12);end.writeUInt32LE(offset,16);
 return Buffer.concat([...parts,central,end]);
}
export function writeCloudflarePlan(plan){
 const root=outputDirectory,receipt=path.join(root,'build-manifest.private.json');
 if(fs.existsSync(root)){
  if(fs.lstatSync(root).isSymbolicLink()||!fs.existsSync(receipt))throw Error('Unrecognized existing output directory');
  const old=readJson(receipt);if(old.kind!=='cloudflare-dashboard-site')throw Error('Unknown previous package');
  if(fs.existsSync(outputZip)&&(!old.archive_sha256||hash(fs.readFileSync(outputZip))!==old.archive_sha256))throw Error('Existing upload ZIP is not the verified previous package');
  if(fs.readdirSync(root).some(name=>name!=='build-manifest.private.json'))throw Error('Unexpected files in the private receipt directory');
 }
 if(!fs.existsSync(root)&&fs.existsSync(outputZip))throw Error('Unowned upload ZIP already exists');
 fs.mkdirSync(root,{recursive:true});
 // Upload the ZIP, not this receipt directory. Keep its uncompressed 28 MB only
 // in memory; writing another full data copy adds no deployment value.
 const archive=makeZip(plan.files);fs.writeFileSync(outputZip,archive);
 // This receipt is deliberately excluded from the upload ZIP (contains sources).
 const receiptData={...plan.manifest,output_mode:'zip_only',archive_bytes:archive.length,archive_sha256:hash(archive)};fs.writeFileSync(receipt,JSON.stringify(receiptData,null,2)+'\n');return receiptData;
}

if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
 try{
  const args=process.argv.slice(2),index=args.indexOf('--origin'),origin=index>=0?args[index+1]:undefined;
  if(args.some((a,i)=>a!=='--write'&&a!=='--origin'&&i!==index+1))throw Error('Only --origin URL and --write are accepted');
  const plan=makeCloudflarePlan({origin});
  const result=args.includes('--write')?writeCloudflarePlan(plan):plan.manifest;
  console.log(JSON.stringify({mode:args.includes('--write')?'written':'dry-run',...result,output_directory:outputDirectory,upload_zip:outputZip},null,2));
 }catch(error){console.error(error.message);process.exitCode=1;}
}
