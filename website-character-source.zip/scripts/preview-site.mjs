import {publicationOrigin} from '../lib/publication-origin.js';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {seed,website,notes,questions} from '../lib/generated-seed.js';
import {createReader} from '../lib/public-research-reader.js';
import {createQuestionsReader,emptyPublicQuestions} from '../lib/public-questions.js';
import {renderHome} from '../lib/home-page.js';
import {applyVisualPolish} from '../lib/site-chrome.js';
const root=path.resolve('site');
const publicRoot=path.resolve('public');
const types={'.html':'text/html; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.json':'application/json','.txt':'text/plain; charset=utf-8','.md':'text/markdown; charset=utf-8','.xml':'application/xml','.zip':'application/zip','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
// Reuse the verified shared snapshot; no new full static build is needed for data QA.
const previewSeed=await fs.readFile(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8').then(JSON.parse).catch(()=>seed);
const reader=createReader({seed:previewSeed,origin:publicationOrigin,notes,questions});
const questionSeed=await fs.readFile(new URL('../../../outputs/public-questions.json',import.meta.url),'utf8').then(JSON.parse).catch(()=>emptyPublicQuestions);
const questionReader=createQuestionsReader({seed:questionSeed,origin:publicationOrigin,fetcher:async()=>new Response(JSON.stringify(questionSeed))});
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://127.0.0.1'),request=new Request(url,{method:req.method});
  const staticResponse=async()=>{
   const decoded=decodeURIComponent(url.pathname),base=decoded.startsWith('/design-library/')||decoded.startsWith('/visuals/')||['/ink-polish.css','/reading-polish.css','/character-scenes.css','/character-scenes.js','/character-motion.js','/ask-master.css','/ask-master.js','/site-ui.css','/site-ui.js','/stock-board.js','/ink-experience.css','/ink-experience.js','/warehouse-theme.css'].includes(decoded)?publicRoot:root,file=path.resolve(base,'.'+decoded+(decoded.endsWith('/')?'index.html':''));
   const relative=path.relative(base,file);if(relative.startsWith('..')||path.isAbsolute(relative))return new Response('Forbidden',{status:403});
   try{const bytes=await fs.readFile(file),body=path.extname(file)==='.html'?applyVisualPolish(bytes.toString()):bytes;return new Response(body,{headers:{'Content-Type':types[path.extname(file)]||'application/octet-stream'}});}catch{return new Response('Not found',{status:404});}
  };
  if(url.pathname==='/visitor-stats.json'){try{const r=await fetch(publicationOrigin+'/visitor-stats.json');res.writeHead(r.status,{'Content-Type':'application/json'});res.end(await r.text());return;}catch{res.writeHead(503);res.end('{}');return;}}
  if(url.pathname==='/visitor-totals.json'){try{const data=await fs.readFile('private/visitor-totals-preview.json','utf8');res.writeHead(200,{'Content-Type':'application/json'});res.end(data);return;}catch{res.writeHead(503);res.end('{}');return;}}
  const response=url.pathname==='/'&&['GET','HEAD'].includes(req.method)?new Response(req.method==='HEAD'?null:renderHome(previewSeed,publicationOrigin),{headers:{'Content-Type':'text/html; charset=utf-8'}}):await questionReader(request,{next:()=>reader(request,{next:staticResponse})});
  res.writeHead(response.status,Object.fromEntries(response.headers));res.end(req.method==='HEAD'?undefined:Buffer.from(await response.arrayBuffer()));
 }catch{res.writeHead(500);res.end('Preview unavailable');}
});
server.listen(Number(process.env.PORT||55215),'127.0.0.1',()=>console.log('Local: http://127.0.0.1:'+server.address().port+'/'));
