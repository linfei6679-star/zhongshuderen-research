import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {stockArchiveReports,stockReports,stockFocusGroups,stockBoardPaths,renderStockBoard} from '../lib/stock-research-table.js';
import {stockResearchTopics} from '../lib/stock-research-topics.js';import {renderKnowledge,renderKnowledgeMarkdown} from '../lib/knowledge-library.js';
import {renderAreaRoute,renderAreaMarkdown} from '../lib/ink-experience.js';import {renderHome} from '../lib/home-page.js';import {sectionQueryModel} from '../lib/section-query.js';
const source=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8')),origin='https://zhongshuderen.pages.dev',u=p=>new URL(p,origin),archive=stockArchiveReports(source.knowledge);
const focusFragment=h=>h.match(/<section class="stock-focus"[\s\S]*?(?=<section class="stock-warehouse")/)[0];
test('the compact homepage and compatible mainline route expose all registered branches',()=>{
 const home=renderHome(source,origin);assert(home.includes('股票研究主线'));assert(!home.includes('贷款与涨价研究'));assert.equal((home.match(/class="project-blossom/g)||[]).length,7);
 const main=renderAreaRoute(source,u('/areas/loan-price/'),origin),md=renderAreaMarkdown(source,u('/areas/loan-price/index.md'),origin);
 for(const t of stockResearchTopics){assert(main.includes('href="'+stockBoardPaths[t.id]+'"'));assert(md.includes(stockBoardPaths[t.id]));}assert(!main.includes('data-fish-scene'));assert(!main.includes('stock-focus-list'));
});
test('all158 published reports are represented, including135 archived approvals without restoring them',()=>{
 assert.equal(archive.length,158);assert.equal(stockReports(source.knowledge).length,23);assert.equal(archive.filter(r=>!r.approved).length,135);
 assert.deepEqual(Object.fromEntries(stockResearchTopics.map(t=>[t.id,archive.filter(r=>r.topic===t.id).length])),{loan:133,price:18,bio:1,'local-state':6});
 for(const r of archive.filter(r=>!r.approved)){assert(!r.focus);assert.equal(r.entry.category,'archives');assert.match(r.status,/批准失效|等待重新复核/);}
});
test('each branch directly renders its independent focus list above a searchable warehouse',()=>{
 for(const t of stockResearchTopics){const html=renderStockBoard(source.knowledge,u(stockBoardPaths[t.id]),origin,t.id);assert(html.indexOf('class="stock-focus"')<html.indexOf('class="stock-warehouse"'));assert(html.includes('id="stock-search"'));assert(html.includes('value="all" selected>全部公开研究（含历史）'));
 const reports=archive.filter(r=>r.topic===t.id);for(const r of reports)assert(html.includes('id="stock-case-'+r.id+'"'));const expected=stockFocusGroups(reports);assert.equal((focusFragment(html).match(/data-focus-code=/g)||[]).length,expected.length);if(!expected.length)assert(focusFragment(html).includes('本分线暂无符合原研究重点标记的当前获批股票'));}
});
test('price focus retains all8 companies beyond the old five-fish cap and is unaffected by warehouse query',()=>{
 const a=renderStockBoard(source.knowledge,u(stockBoardPaths.price),origin,'price'),b=renderStockBoard(source.knowledge,u(stockBoardPaths.price+'?q=完全无匹配&date=2099-01-01'),origin,'price');
 const codes=h=>[...focusFragment(h).matchAll(/data-focus-code="(\d+)"/g)].map(m=>m[1]);assert.equal(codes(a).length,8);assert.deepEqual(codes(a),codes(b));assert(b.includes('id="stock-empty">'));
 const groups=stockFocusGroups(archive.filter(r=>r.topic==='price'));for(let i=1;i<groups.length;i++)assert(groups[i-1].updatedMs>=groups[i].updatedMs);
});
test('historical positive directions and approved auxiliary or ownership facts do not become focus',()=>{
 for(const topic of ['loan','bio','local-state'])assert.equal(stockFocusGroups(archive.filter(r=>r.topic===topic)).length,0);
 assert(archive.some(r=>!r.approved&&r.direction==='潜在受益'));const first=archive.find(r=>r.focus);const opposing={...first,id:'local-opposite',direction:'潜在受损',focus:false};const g=stockFocusGroups([first,opposing])[0];assert.equal(g.cases.length,2);assert.equal(g.focusCases.length,1);
});
test('HTML and Markdown preserve every historical report and its branch context',()=>{
 for(const t of stockResearchTopics){const html=renderKnowledge(source.knowledge,u(stockBoardPaths[t.id]),origin),md=renderKnowledgeMarkdown(source.knowledge,u(stockBoardPaths[t.id]+'index.md'),origin);assert(html.includes('重点关注股票'));assert(md.includes('## 重点关注股票'));assert(md.includes('## 研究仓库'));
 for(const r of archive.filter(r=>r.topic===t.id)){assert(md.includes('/library/'+r.id+'/'));assert(md.includes(r.status));assert(html.includes('/library/'+r.id+'/'));}}
 const old=archive.find(r=>!r.approved&&r.topic==='loan');const html=renderKnowledge(source.knowledge,u('/library/'+old.id+'/?board=loan&from='+old.code+'&level=all'),origin);assert(html.includes(old.status));assert(html.includes('stock-research-loan-expansion/?q='+old.code));
});
test('legacy scoped topic searches include archived research and all registered branches',()=>{
 for(const t of stockResearchTopics){const m=sectionQueryModel(source,u('/areas/loan-price/search/?topic='+t.id),'loan-price');assert.equal(m.state.topic,t.id);const ids=new Set(m.results.map(x=>x.doc.id));for(const r of archive.filter(r=>r.topic===t.id))assert(ids.has(r.id),'not searchable '+r.id);}
});
test('filtered warehouse Markdown and article Markdown retain the same whitelisted return state',()=>{
 const query='?q=000930&topic=price&level=all&sort=source&date=2026-10-13',html=renderStockBoard(source.knowledge,u(stockBoardPaths.all+query),origin),href=html.match(/data-stock-markdown href="([^"]+)"/)[1].replaceAll('&amp;','&');
 const state=u(href);for(const [k,v]of new URLSearchParams(query))assert.equal(state.searchParams.get(k),v,k);
 const md=renderKnowledgeMarkdown(source.knowledge,state,origin);assert(md.includes('## 研究仓库'));assert(md.includes('返回本次查询'));assert(md.includes('topic=price'));assert(md.includes('date=2026-10-13'));
 const r=archive.find(r=>r.code==='000930'&&r.topic==='price'),article='/library/'+r.id+'/?board=all&from=000930&topic=price&level=all&sort=source&date=2026-10-13';
 const body=renderKnowledge(source.knowledge,u(article),origin),mdHref=body.match(/href="([^"]+index\.md\?board=[^"]+)"/)?.[1]||body.match(/href="([^"]+index\.md\?[^"]*board=all[^"]+)"/)?.[1];assert(mdHref);const text=renderKnowledgeMarkdown(source.knowledge,u(mdHref.replaceAll('&amp;','&')),origin);assert(text.includes('返回本次查询'));assert(text.includes('q=000930'));assert(text.includes('topic=price'));assert(text.includes('sort=source'));assert(text.includes('date=2026-10-13'));
});
