import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {sections} from '../lib/section-registry.js';
import {renderAreaRoute} from '../lib/ink-experience.js';
const data=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8'));
const origin='https://zhongshuderen.pages.dev',render=p=>renderAreaRoute(data,new URL(p,origin),origin);
test('each second level exposes a named submit, all-research entry and return without scripts',()=>{
 for(const s of sections.filter(s=>s.id!=='loan-price')){const html=render('/areas/'+s.id+'/');assert(html.includes('>搜索 <span'));assert(html.includes('class="browse-area" href="/areas/'+s.id+'/search/"'));assert(html.includes('← 返回项目树'));assert(html.includes('画中互动'));assert(!html.includes('class="result-item"'));}
 const loan=render('/areas/loan-price/?topic=price');assert(loan.includes('data-fixed-topic="price"'));assert(loan.includes('stock-focus'));
});
test('active filters have individually removable links and no-results recovery preserves the query',()=>{
 const html=render('/areas/mengya-company/search/?q=没有匹配的本地测试词&type=stocks&date=2026-10-01&page=3');
 assert(html.includes('移除类别：公司与股票'));assert(html.includes('移除日期：2026-10-01'));assert(html.includes('清除筛选，重新查找'));assert(html.includes('浏览本区全部研究'));assert(html.includes('name="type" value="stocks"'));assert(html.includes('name="date" value="2026-10-01"'));assert(!html.includes('class="warehouse-filter-drawer" open'));
 const links=[...html.matchAll(/aria-label="移除([^"]+)" href="([^"]+)"/g)].map(m=>({label:m[1],url:new URL(m[2].replaceAll('&amp;','&'),origin)}));
 const category=links.find(l=>l.label.startsWith('类别'));assert.equal(category.url.searchParams.get('type'),null);assert.equal(category.url.searchParams.get('date'),'2026-10-01');assert.equal(category.url.searchParams.get('q'),'没有匹配的本地测试词');
 const date=links.find(l=>l.label.startsWith('日期'));assert.equal(date.url.searchParams.get('date'),null);assert.equal(date.url.searchParams.get('type'),'stocks');
});
