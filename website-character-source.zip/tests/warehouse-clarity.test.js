import test from 'node:test';
import assert from 'node:assert/strict';
import {renderWarehouseHero,renderWarehouseSummary,renderWarehouseFacets,renderWarehouseResults,renderWarehouseRelated} from '../lib/warehouse-theme.js';

const unesc=s=>s.replaceAll('&amp;','&').replaceAll('&quot;','"');
test('one readable result stream preserves interleaved rank, contextual URLs, dates and status',()=>{
 const rows=[
  {doc:{category:'methods',title:'方法 A',date:'2026-10-03',status:'尚待验证',summary:'方法 A 摘要',path:'/library/a/'}},
  {doc:{category:'stocks',title:'公司 B',date:'2026-10-01',status:'原报告观察',summary:'公司 B 摘要',path:'/stocks/000001/'}},
  {doc:{category:'methods',title:'方法 C',date:'2026-09-30',status:'保留失败',summary:'方法 C 摘要',path:'/library/c/'}}
 ];
 const before=JSON.stringify(rows),href=d=>d.path+'?area=mengya-company&q=研究&page=2';
 const html=renderWarehouseResults(rows,{label:k=>({methods:'研究方法',stocks:'公司材料'}[k]),href,start:15});
 assert.equal((html.match(/class="warehouse-shelf-group/g)||[]).length,1);
 assert.equal((html.match(/class="warehouse-record-category"/g)||[]).length,3);
 assert(!html.includes('本组 '));assert(!html.includes('<header>'));
 assert.deepEqual([...html.matchAll(/class="result-item" href="([^"]+)"/g)].map(m=>unesc(m[1])),rows.map(({doc})=>href(doc)));
 assert.deepEqual([...html.matchAll(/<h3>(.*?)<\/h3>/g)].map(m=>m[1]),rows.map(({doc})=>doc.title));
 for(const {doc}of rows){assert(html.includes(doc.date));assert(html.includes(doc.status));}
 assert(html.includes('<span>16</span>'));assert.equal((html.match(/>阅读 /g)||[]).length,3);
 assert.equal(JSON.stringify(rows),before);
});
test('optional category and directory navigation are native collapsed disclosures with intact destinations',()=>{
 const facets=renderWarehouseFacets(new Map([['tools',3]]),()=>'<工具>',()=>'/areas/ai-tools/search/?q=模型&type=tools');
 const related=renderWarehouseRelated([{label:'更多研究',href:'/library/?q=模型&source=area'}]);
 for(const html of [facets,related]){assert(html.startsWith('<details class="warehouse-extra-box warehouse-fold">'));assert(html.includes('<summary'));assert(!/<details[^>]*\bopen(?:\s|=|>)/.test(html));}
 assert(facets.includes('&lt;工具&gt;'));assert(facets.includes('<b>3</b>'));assert(facets.includes('q=模型&amp;type=tools'));
 assert(related.includes('q=模型&amp;source=area'));
});
test('compact result summary reports zero and nonzero windows without card-style duplicated figures',()=>{
 const summary=renderWarehouseSummary({total:1032,shown:15,page:2,pages:69});
 assert(summary.includes('1,032'));assert(summary.includes('本页 15 条'));assert(summary.includes('第 2 / 69 页'));assert(!summary.includes('<div><strong>'));
 const empty=renderWarehouseSummary({total:0,shown:0,page:1,pages:1});assert(empty.includes('<strong>0</strong>'));assert(empty.includes('第 1 / 1 页'));
 const h=renderWarehouseResults([]);assert(h.includes('没有匹配记录不代表事情没有发生'));assert(!h.includes('warehouse-record'));
});
test('warehouse hero names arrow-only search without changing action, query, or other buttons',()=>{
 const form='<form action="/areas/ai-tools/search/" method="get"><input name="q" value="模型"><input type="hidden" name="type" value="tools"><button type="submit" aria-label="提交搜索">↗</button><button type="button">清除</button></form>';
 const h=renderWarehouseHero({id:'ai-tools',title:'工具',searchHtml:form});
 assert(h.includes('aria-label="提交搜索">搜索</button>'));assert(h.includes('<button type="button">清除</button>'));assert(h.includes('action="/areas/ai-tools/search/"'));assert(h.includes('name="q" value="模型"'));assert(h.includes('name="type" value="tools"'));
});
test('result fields and contextual query strings stay escaped',()=>{
 const h=renderWarehouseResults([{title:'<script>unsafe</script>',category:'<img>',status:'"待核"',path:'/library/test/'}],{href:d=>d.path+'?q="x"&page=2'});
 assert(!h.includes('<script>'));assert(!h.includes('<img>'));assert(h.includes('&lt;script&gt;unsafe'));assert(h.includes('q=&quot;x&quot;&amp;page=2'));assert(h.includes('材料时点见正文'));
});
