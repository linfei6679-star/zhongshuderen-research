import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {renderSectionLanding,renderSectionSearch} from '../lib/ink-experience.js';
import {renderHome} from '../lib/home-page.js';
import {characterScenes,renderCharacterScene} from '../lib/character-scenes.js';
import {lieziCharacterAssets} from '../lib/visual-library.js';
import {characterPhase,fishPose,rodPose,createImageLoader} from '../public/character-motion.js';
import {makeCloudflarePlan} from '../scripts/build-cloudflare.mjs';
const data=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8')),origin='https://zhongshuderen.pages.dev',u=p=>new URL(p,origin);
test('only the two approved second-level pages include their own character configuration',()=>{
 const before=JSON.stringify(data);
 for(const [id,config] of Object.entries(characterScenes)){
  const html=renderSectionLanding(data,u('/areas/'+id+'/'),origin);
  assert(html.includes('data-character="'+config.id+'"'));assert(html.includes(config.atlas));assert(html.includes(config.clean));
  for(const other of Object.values(characterScenes))if(other!==config)assert(!html.includes(other.atlas));
  assert(!html.includes('class="scene-joint"'));assert(!html.includes('data-state="auto"'));assert(html.includes('character-scenes.js'));
  const search=renderSectionSearch(data,u('/areas/'+id+'/search/'),origin);assert(!search.includes('character-scenes.js'));
 }
 assert.equal(renderCharacterScene('quant-prediction'),'');assert(!renderHome(data,origin).includes('character-scenes.js'));assert.equal(JSON.stringify(data),before);
});
test('real company fish and selected topics survive; sample fish never enters the site renderer',()=>{
 for(const topic of ['loan','price']){
  const html=renderSectionLanding(data,u('/areas/loan-price/?topic='+topic),origin);const fish=[...html.matchAll(/class="ink-fish"[^>]*href="([^"]+)"/g)];assert(fish.length>0);
  for(const match of fish){const link=u(match[1].replaceAll('&amp;','&'));assert.equal(link.searchParams.get('topic'),topic);assert.match(link.searchParams.get('q'),/^\d{6}$/);}
  assert(!html.includes('id="fish"'));assert(html.includes('x="1490" y="315" width="135" height="101.25"'));assert(html.includes('M1490 342Q1557.5 370.35 1625 342V416.25H1490Z'));
 }
});
test('rod grip and tip follow each registered hand and lift instead of a fixed old overlay',()=>{
 const c=characterScenes['loan-price'];
 for(let frame=0;frame<4;frame++)for(const lift of [0,.5,1]){const pose=rodPose(c,frame,lift);assert.deepEqual(pose.grip,c.frameGrips[frame]);assert(pose.tip.every(Number.isFinite));}
 assert.notDeepEqual(rodPose(c,0,0).tip,rodPose(c,1,0).tip);assert.notDeepEqual(rodPose(c,0,0).tip,rodPose(c,0,1).tip);
});
test('all company fish paths remain below or beside the actor until the basket entry',()=>{
 for(const start of [[1050,490],[1350,545],[1100,660],[1370,735],[1115,830]]){
  for(let i=0;i<=1000;i++){const p=i/1000,r=fishPose(start,p);assert(r.x>=0&&r.x<=1672);assert(r.y>=295&&r.y<=941);assert(r.scale>=.12&&r.scale<=1);assert(r.opacity>=0&&r.opacity<=1);
   if(p>=.60&&p<.88)assert(r.y>=417||r.x>=1600,'fish crosses the actor instead of passing below/right');
  }
  assert.deepEqual(fishPose(start,.9,{stopped:true}),{x:start[0],y:start[1],scale:1,opacity:1});
 }
 assert.equal(fishPose([1050,490],.94).y,342);assert.equal(fishPose([1050,490],1).opacity,0);
 assert.equal(characterPhase('fisher',3000,0).lift,0);assert.equal(characterPhase('fisher',11200,5).selected,1);
});
test('a failed image Promise is evicted and a later ordinary retry can succeed',async()=>{
 let requests=0;
 class ImageStub{set src(value){requests++;queueMicrotask(()=>{if(requests===1)this.onerror();else{this.naturalWidth=100;this.onload();}});}}
 const loader=createImageLoader(ImageStub);await assert.rejects(loader.load('/owned-image.webp'));await loader.load('/owned-image.webp');assert.equal(requests,2);await loader.load('/owned-image.webp');assert.equal(requests,2);
});
test('the release whitelist includes four unique public assets and no private prototype files',()=>{
 const plan=makeCloudflarePlan({origin});let bytes=0;
 for(const asset of lieziCharacterAssets){const p=asset.src.slice(1);assert(plan.files.has(p));bytes+=plan.files.get(p).body.length;}
 assert.equal(bytes,1274798);assert.equal(lieziCharacterAssets.length,4);
 assert(![...plan.files.keys()].some(p=>p.includes('motion-manifest')||p.includes('server.mjs')||p.includes('人物互动样板')||p.includes('素材生成清单')));
});
