import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {renderSectionLanding,renderSectionSearch} from '../lib/ink-experience.js';
import {renderHome} from '../lib/home-page.js';
import {characterScenes,renderCharacterScene} from '../lib/character-scenes.js';
import {lieziCharacterAssets} from '../lib/visual-library.js';
import {characterPhase,fishPose,rodPose,createImageLoader} from '../public/character-motion.js';
import {renderAskLanding,renderAskMaster} from '../lib/ask-master-page.js';
import crypto from 'node:crypto';
import {makeCloudflarePlan} from '../scripts/build-cloudflare.mjs';
const data=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8')),origin='https://zhongshuderen.pages.dev',u=p=>new URL(p,origin);
test('eight second-level pages each include only their own character assets; warehouses stay static',()=>{
 const before=JSON.stringify(data);
 for(const [id,config] of Object.entries(characterScenes)){
  const html=id==='ask'?renderAskLanding(origin):renderSectionLanding(data,u('/areas/'+id+'/'),origin);
  assert(html.includes('data-character="'+config.id+'"'));assert(html.includes(config.atlas));assert(html.includes(config.clean));
  for(const other of Object.values(characterScenes))if(other!==config)assert(!html.includes(other.atlas));
  assert(!html.includes('class="scene-joint"'));assert(!html.includes('data-state="auto"'));assert(html.includes('character-scenes.js'));
  if(id!=='ask'){const search=renderSectionSearch(data,u('/areas/'+id+'/search/'),origin);assert(!search.includes('character-scenes.js'));}
 }
 assert.equal(Object.keys(characterScenes).length,8);assert.equal(renderCharacterScene('unknown'),'');assert(!renderHome(data,origin).includes('character-scenes.js'));assert.equal(JSON.stringify(data),before);
});
test('mainline uses registered branch links rather than a limited company-fish preview',()=>{
 const html=renderSectionLanding(data,u('/areas/loan-price/'),origin);assert(html.includes('stock-branch-picker'));assert(!html.includes('data-fish-scene'));assert(html.includes('data-character="fisher"'));
 for(const topic of ['loan','price']){const branch=renderSectionLanding(data,u('/areas/loan-price/?topic='+topic),origin);assert(branch.includes('data-fixed-topic="'+topic+'"'));assert(branch.includes('stock-focus'));}
});

test('rod grip and tip follow each registered hand and lift instead of a fixed old overlay',()=>{
 const c=characterScenes['loan-price'];
 for(let frame=0;frame<4;frame++)for(const lift of [0,.5,1]){const pose=rodPose(c,frame,lift);assert.deepEqual(pose.grip,c.frameGrips[frame]);assert(pose.tip.every(Number.isFinite));}
 assert.notDeepEqual(rodPose(c,0,0).tip,rodPose(c,1,0).tip);assert.notDeepEqual(rodPose(c,0,0).tip,rodPose(c,0,1).tip);
});
test('all company fish paths remain below or beside the actor until the basket entry',()=>{
 for(const start of [[1050,490],[1350,545],[1100,660],[1370,735],[1115,830]]){
  for(let i=0;i<=1000;i++){const p=i/1000,r=fishPose(start,p);assert(r.x>=0&&r.x<=1672);assert(r.y>=295&&r.y<=941);assert(r.scale>=.12&&r.scale<=1);assert(r.opacity>=0&&r.opacity<=1);
   if(p>=.60&&p<.88)assert(r.y>=417||r.x>=1600,'fish crosses the actor instead of passing below/right');
  }
  assert.deepEqual(fishPose(start,.9,{stopped:true}),{x:start[0],y:start[1],scale:1,opacity:1});
 }
 assert.equal(fishPose([1050,490],.94).y,342);assert.equal(fishPose([1050,490],1).opacity,0);
 assert.equal(characterPhase('fisher',3000,0).lift,0);assert.equal(characterPhase('fisher',11200,5).selected,1);
});
test('a failed image Promise is evicted and a later ordinary retry can succeed',async()=>{
 let requests=0;
 class ImageStub{set src(value){requests++;queueMicrotask(()=>{if(requests===1)this.onerror();else{this.naturalWidth=100;this.onload();}});}}
 const loader=createImageLoader(ImageStub);await assert.rejects(loader.load('/owned-image.webp'));await loader.load('/owned-image.webp');assert.equal(requests,2);await loader.load('/owned-image.webp');assert.equal(requests,2);
});
test('the release whitelist includes sixteen unique public assets and no private prototype files',()=>{
 const plan=makeCloudflarePlan({origin});let bytes=0;
 for(const asset of lieziCharacterAssets){const p=asset.src.slice(1);assert(plan.files.has(p));bytes+=plan.files.get(p).body.length;}
 assert.equal(bytes,1274798+2510542);assert.equal(lieziCharacterAssets.length,16);
 assert(![...plan.files.keys()].some(p=>p.includes('motion-manifest')||p.includes('server.mjs')||p.includes('人物互动样板')||p.includes('素材生成清单')));
});

 test('every registered actor has a finite explicit cycle, stable start, and a separate response frame',()=>{
 for(const c of Object.values(characterScenes)){assert.equal(characterPhase(c.id,0).frame,0);const frames=new Set();for(let t=0;t<180000;t+=50){const phase=characterPhase(c.id,t,5);assert([0,1,2].includes(phase.frame));frames.add(phase.frame);}assert.deepEqual([...frames].sort(),[0,1,2]);assert.equal(c.registration.length,4);for(const r of c.registration)assert(Number.isFinite(r.x)&&Number.isFinite(r.y));}
 assert.throws(()=>characterPhase('not-registered',100),/Unknown/);assert.throws(()=>characterPhase('archer',NaN),/clock/);
 });
 test('archer arrow, release and impact share a phase; macro paths bind the matching arm',()=>{
 for(let t=0;t<=12000;t+=5){const p=characterPhase('archer',t);if(p.arrowVisible||p.impact)assert.equal(p.frame,2);assert(!(p.arrowVisible&&p.impact));assert(p.arrowProgress>=0&&p.arrowProgress<=1);}
 assert.equal(characterPhase('archer',12000).frame,0);for(let t=0;t<16000;t+=50){let p=characterPhase('traveler',t);if(p.path===0)assert.equal(p.frame,1);if(p.path===1)assert.equal(p.frame,2);}
 });
 test('ask form stays byte-identical and escaped; only its outer static theme changes',()=>{
 const html=renderAskMaster(origin),fragment=html.match(/<form id="master-question-form"[\s\S]*?<\/form>/)[0];
 assert.equal(crypto.createHash('sha256').update(fragment).digest('hex'),'d598a94acbb84385e149d0ef2b974b9315450ac493b2846793a0c348baa8e81b');
 assert.equal((html.match(/<h1\b/g)||[]).length,1);assert(!html.includes('character-scenes.js'));assert(html.includes('/visuals/liezi/08-ask.webp'));assert(!html.includes('character-clean'));
 const draft=renderAskMaster(origin,{question:'</textarea><script>alert(1)</script>'});assert(draft.includes('&lt;/textarea&gt;&lt;script&gt;'));assert.equal((draft.match(/<form\b/g)||[]).length,1);
 });
