import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {renderSearchPage} from '../lib/research-search.js';
import {renderKnowledge} from '../lib/knowledge-library.js';
import {renderSectionLanding} from '../lib/ink-experience.js';
import {selectStockGroups,stockReports,stockArchiveReports,renderStockBoard} from '../lib/stock-research-table.js';
const data=JSON.parse(fs.readFileSync(new URL('../../../outputs/public-research-data.json',import.meta.url),'utf8'));
const origin='https://zhongshuderen.pages.dev',u=p=>new URL(p,origin),decode=s=>s.replaceAll('&amp;','&');
test('global and category result links preserve the clamped page through an article round trip',()=>{
 for(const path of ['/library/?q=量化&page=2','/library/category/stocks/?page=2']){
  const html=renderSearchPage(data.knowledge,u(path),origin,{},path.includes('category')?'stocks':undefined);
  const href=decode(html.match(/class="result-item"[^>]*href="([^"]+)"/)?.[1]||html.match(/href="([^"]+)"[^>]*class="result-item"/)?.[1]||'');
  assert(href, 'expected an article link');assert.equal(u(href).searchParams.get('page'),'2');
  const article=renderKnowledge(data.knowledge,u(href),origin);
  const back=u(decode(article.match(/class="reader-footer"><a href="([^"]+)"/)[1]));
  assert.equal(back.searchParams.get('page'),'2');assert.equal(back.searchParams.get('q'),u(path).searchParams.get('q'));
  if(path.includes('category'))assert.equal(back.searchParams.get('type'),'stocks');
 }
});
test('stock report and return URLs retain selected topic and filters without accepting unknown topics',()=>{
 const url=u('/library/stock-research-results/?q=000930&topic=price&level=all&sort=source&date=2026-10-17');
 const html=renderStockBoard(data.knowledge,url,origin);
 const href=decode(html.match(/data-primary-report href="([^"]+)"/)[1]);
 assert.equal(u(href).searchParams.get('topic'),'price');
 const article=renderKnowledge(data.knowledge,u(href),origin),back=u(decode(article.match(/class="reader-footer"><a href="([^"]+)"/)[1]));
 for(const key of ['topic','q','level','sort','date'])assert.equal(back.searchParams.get(key),url.searchParams.get(key),key);
 assert(!renderKnowledge(data.knowledge,u(href.replace('topic=price','topic=unknown')),origin).includes('topic=unknown'));
});
test('server source-date ordering matches both grouped cases and visible row order',()=>{
 const base=stockReports(data.knowledge)[0];
 const a={...base,id:'new-update',code:'900001',updatedMs:300,sourceMs:10};
 const b={...base,id:'new-source',code:'900001',updatedMs:100,sourceMs:400};
 const c={...base,id:'other-stock',code:'900002',updatedMs:200,sourceMs:200};
 const groups=selectStockGroups([a,b,c],{level:'all',sort:'source'});
 assert.deepEqual(groups.map(g=>g.code),['900001','900002']);assert.equal(groups[0].cases[0].id,'new-source');
 const reports=stockArchiveReports(data.knowledge),wanted=selectStockGroups(reports,{level:'all',sort:'source',topic:'price'});
 const html=renderStockBoard(data.knowledge,u('/library/stock-research-results/?topic=price&level=all&sort=source'),origin);
 const actual=[...html.matchAll(/<tr class="stock-row" data-code="(\d+)"(?! hidden)>/g)].map(m=>m[1]);
 assert.deepEqual(actual,wanted.map(g=>g.code));
});
test('legacy topic shortcuts open their matching branch and keep historical report routes',()=>{
 for(const topic of ['loan','price']){const html=renderSectionLanding(data,u('/areas/loan-price/?topic='+topic),origin);assert(html.includes('data-fixed-topic="'+topic+'"'));assert(html.includes('class="stock-focus"'));assert(html.includes('class="stock-warehouse"'));for(const r of stockArchiveReports(data.knowledge).filter(r=>r.topic===topic))assert(html.includes('/library/'+r.id+'/'));}
});
